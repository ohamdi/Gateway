"""Orchestration : périmètre → faits → narration IA → PPTX.

`ApplicationService` est le seul point d'entrée des routes. Il tient la règle du
produit : les chiffres viennent de `metrics`, la narration de `prompting` +
`llm`, le rendu de `pptx_builder`, et chaque étape peut échouer sans emporter les
autres — un modèle indisponible laisse des slides vides et un avertissement, pas
une génération ratée (sauf si la définition l'exige).
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

from . import ai_config
from . import context as context_module
from . import narrative as narrative_module
from . import prompting
from . import templates as templates_module
from . import verify
from .auth import AuthService, Principal
from .config import DataSourceConfig, Settings
from .errors import APIError
from .metrics import MetricsEngine, ReportScope
from .narrative import sanitise
from .pptx_builder import DeckBuilder
from .reportings import ReportingLibrary
from .schemas import (
    ClientGroup,
    ContextResponse,
    GenerateRequest,
    GenerationResponse,
    GroupGenerationResponse,
    PromptTarget,
    PromptVariant,
    ReportingDefinition,
    SlideResult,
    SlideVerification,
)
from .storage import DatasetRepository

logger = logging.getLogger(__name__)

#: Nombre de générations conservées en mémoire pour l'historique de l'interface.
RUN_HISTORY_LIMIT = 50

#: Dataset qui rattache les clients aux groupes : lignes `group_id`,
#: `group_name`, `client_id`.
GROUPS_DATASET = "client_groups"

#: Principal sans restriction, pour les lectures internes (inventaire des
#: prompts, résolution d'un nom de groupe) : ce ne sont pas des données client.
_ALL_CLIENTS = Principal(username="", role="admin", client_id="")


class ApplicationService:
    def __init__(
        self,
        settings: Settings,
        config: DataSourceConfig,
        repository: DatasetRepository,
        library: ReportingLibrary,
        metrics: MetricsEngine,
    ) -> None:
        self.settings = settings
        self.config = config
        self.repository = repository
        self.library = library
        self.metrics = metrics
        self.auth = AuthService(repository)
        self.llm: Any = None
        self._runs: list[dict[str, Any]] = []

    # ------------------------------------------------------------ Clients

    def clients(self, principal: Principal) -> list[dict[str, Any]]:
        """Clients visibles par l'utilisateur, triés, avec leur actif calculé."""
        allowed = self.allowed_client_ids(principal)
        frame = self.repository.frame("clients")
        if frame.empty:
            return []
        holdings = self.repository.frame("holdings")
        totals: dict[str, float] = {}
        if not holdings.empty and "client_id" in holdings and "market_value" in holdings:
            grouped = holdings.groupby(holdings["client_id"].astype(str))["market_value"].sum()
            totals = {str(key): float(value) for key, value in grouped.items()}
        rows: list[dict[str, Any]] = []
        for record in frame.to_dict("records"):
            client_id = str(record.get("client_id", ""))
            if allowed is not None and client_id not in allowed:
                continue
            rows.append(
                {
                    "client_id": client_id,
                    "client_name": str(record.get("client_name", "") or client_id),
                    "segment": str(record.get("segment", "") or ""),
                    "domicile": str(record.get("domicile", "") or ""),
                    "relationship_manager": str(record.get("relationship_manager", "") or ""),
                    "base_ccy": str(record.get("base_ccy", "") or "EUR"),
                    "aum": round(totals.get(client_id, 0.0), 2),
                }
            )
        return sorted(rows, key=lambda row: row["client_name"].lower())

    def allowed_client_ids(self, principal: Principal) -> set[str] | None:
        """`None` = accès à tous les clients ; sinon la liste stricte autorisée."""
        client_id = str(principal.client_id or "").strip()
        if client_id and client_id.lower() not in {"*", "all", "tous"}:
            return {client_id}
        return None

    # --------------------------------------------------- Groupes de clients

    def client_names(self) -> dict[str, str]:
        """Table `client_id` → nom affiché, lue une fois par appel."""
        frame = self.repository.frame("clients")
        if frame.empty or "client_id" not in frame:
            return {}
        names: dict[str, str] = {}
        for record in frame.to_dict("records"):
            identifier = str(record.get("client_id", "") or "").strip()
            if identifier:
                names[identifier] = str(record.get("client_name", "") or identifier)
        return names

    def groups(self, principal: Principal) -> list[dict[str, Any]]:
        """Groupes de clients du dataset `client_groups`, filtrés par périmètre.

        Un groupe dont aucun client n'est visible par l'utilisateur n'apparaît
        pas ; les clients d'un groupe hors périmètre sont simplement retirés de
        ses membres. Un `client_id` inconnu du dataset `clients` est conservé à
        part (`missing_client_ids`) pour signaler une coquille dans la source.
        """
        allowed = self.allowed_client_ids(principal)
        names = self.client_names()
        entries: dict[str, dict[str, Any]] = {}
        for record in self.repository.records(GROUPS_DATASET):
            group_id = str(record.get("group_id", "") or "").strip()
            client_id = str(record.get("client_id", "") or "").strip()
            if not group_id or not client_id:
                continue
            entry = entries.setdefault(
                group_id,
                {"group_id": group_id, "group_name": "", "client_ids": [], "missing_client_ids": []},
            )
            if not entry["group_name"]:
                entry["group_name"] = str(record.get("group_name", "") or "").strip()
            if client_id not in names:
                if client_id not in entry["missing_client_ids"]:
                    entry["missing_client_ids"].append(client_id)
                continue
            if allowed is not None and client_id not in allowed:
                continue
            if client_id not in entry["client_ids"]:
                entry["client_ids"].append(client_id)
        groups: list[dict[str, Any]] = []
        for entry in entries.values():
            if not entry["client_ids"]:
                continue
            group = ClientGroup(
                group_id=entry["group_id"],
                group_name=entry["group_name"] or entry["group_id"],
                client_ids=entry["client_ids"],
                clients=[
                    {"client_id": client_id, "client_name": names.get(client_id, client_id)}
                    for client_id in entry["client_ids"]
                ],
                missing_client_ids=entry["missing_client_ids"],
            )
            payload = group.model_dump()
            payload["count"] = group.count
            groups.append(payload)
        return sorted(groups, key=lambda group: (group["group_name"].lower(), group["group_id"]))

    def group(self, group_id: str, principal: Principal) -> dict[str, Any]:
        """Un groupe précis, tel que le voit l'utilisateur connecté."""
        identifier = str(group_id or "").strip()
        if not identifier:
            raise APIError(400, "Groupe de clients non précisé.")
        for entry in self.groups(principal):
            if entry["group_id"] == identifier:
                return entry
        raise APIError(404, f"Groupe inconnu ou hors de votre périmètre : {identifier}")

    def group_client_ids(self, group_id: str, principal: Principal) -> list[str]:
        return list(self.group(group_id, principal)["client_ids"])

    def _group_ids_for_client(self, client_id: str) -> list[str]:
        """Groupes contenant un client, sans filtre de périmètre (résolution prompt)."""
        identifier = str(client_id or "").strip()
        if not identifier:
            return []
        seen = {
            str(record.get("group_id", "") or "").strip()
            for record in self.repository.records(GROUPS_DATASET)
            if str(record.get("client_id", "") or "").strip() == identifier
        }
        return sorted(group_id for group_id in seen if group_id)

    # --------------------------------------------------------------- Données

    def datasets(self) -> list[dict[str, Any]]:
        return self.repository.status()

    def dataset_preview(self, name: str, limit: int = 25) -> dict[str, Any]:
        if name not in self.config.dataset_paths():
            raise APIError(404, f"Dataset inconnu : {name}")
        path = self.repository.path(name)
        return {
            "name": name,
            "path": str(path),
            "columns": self.repository.columns(name),
            "rows": self.repository.preview(name, limit),
            "total": int(len(self.repository.frame(name))),
        }

    def update_datasets(self, payload: dict[str, Any]) -> dict[str, Any]:
        updates = {key: value for key, value in payload.items() if value is not None}
        if not updates:
            return self.config.load()
        self.config.update(updates)
        self.repository.invalidate()
        if self.llm is not None:
            self.llm.config_changed()
        return self.config.load()

    # --------------------------------------------------------------- Périmètre

    def scope(
        self,
        definition: ReportingDefinition,
        principal: Principal,
        request: GenerateRequest | None = None,
    ) -> ReportScope:
        """Périmètre d'une génération, verrouillé sur les droits de l'utilisateur."""
        request = request or GenerateRequest()
        allowed = self.allowed_client_ids(principal)
        group_id = str(request.group_id or "").strip()
        client_id = str(request.client_id or "").strip()
        if not client_id and group_id:
            # Aperçu de contexte pour un groupe : on montre le premier client
            # accessible. La génération d'un groupe passe par `generate_group`,
            # qui fixe explicitement le client de chaque deck.
            members = self.group_client_ids(group_id, principal)
            client_id = members[0] if members else ""
        client_id = client_id or definition.default_client_id or ""
        if allowed is not None:
            if not client_id:
                client_id = next(iter(allowed))
            if client_id not in allowed:
                raise APIError(403, "Ce client ne vous est pas attribué.")
        portfolios = tuple(str(value) for value in request.portfolio_ids if str(value))
        period = str(request.period or definition.period.type)
        return ReportScope(
            client_id=client_id,
            portfolio_ids=portfolios,
            as_of=str(request.as_of or "").strip(),
            period_label=str(request.period_label or definition.period.label or "").strip(),
            period=period,  # type: ignore[arg-type]
        )

    # ------------------------------------------------------------- Prompts

    def prompt_for(
        self, reporting_id: str, client_id: str = "", group_id: str = ""
    ) -> dict[str, Any]:
        """Prompt effectif d'une cible, par priorité : client > groupe > défaut.

        Un prompt propre au client prime toujours sur celui de son groupe, qui
        prime lui-même sur `prompt.md`. Le groupe peut être explicite (demande
        d'un groupe précis) ou déduit de l'appartenance du client au dataset
        `client_groups`.
        """
        client_id = str(client_id or "").strip()
        group_id = str(group_id or "").strip()
        if client_id and self.library.has_variant(reporting_id, "client", client_id):
            return {
                "prompt": self.library.load_variant(reporting_id, "client", client_id),
                "source": "client",
                "target_id": client_id,
            }
        candidates = [group_id] if group_id else self._group_ids_for_client(client_id)
        for candidate in candidates:
            if self.library.has_variant(reporting_id, "groupe", candidate):
                return {
                    "prompt": self.library.load_variant(reporting_id, "groupe", candidate),
                    "source": "groupe",
                    "target_id": candidate,
                }
        return {
            "prompt": self.library.load_prompt(reporting_id),
            "source": "default",
            "target_id": "",
        }

    def prompt_variant(
        self, reporting_id: str, principal: Principal | None = None, request: GenerateRequest | None = None
    ) -> dict[str, Any]:
        """Lecture d'un prompt pour une cible : le fichier écrit et celui qui prime."""
        request = request or GenerateRequest()
        target = PromptTarget(client_id=request.client_id, group_id=request.group_id)
        exists = bool(target.target_id) and self.library.has_variant(
            reporting_id, target.kind, target.target_id
        )
        resolved = self.prompt_for(reporting_id, target.client_id, target.group_id)
        prompt = (
            self.library.load_variant(reporting_id, target.kind, target.target_id)
            if exists
            else resolved["prompt"]
        )
        return {
            "reporting_id": reporting_id,
            "kind": target.kind,
            "target_id": target.target_id,
            "prompt": prompt,
            "source": resolved["source"],
            "exists": exists,
            "filename": (
                self.library.variant_path(reporting_id, target.kind, target.target_id)
                .relative_to(self.library.folder(reporting_id))
                .as_posix()
                if target.target_id
                else "prompt.md"
            ),
        }

    def prompt_variants(self, reporting_id: str) -> list[dict[str, Any]]:
        """Tous les prompts du dossier (défaut + variantes) avec leur cible lisible."""
        names = self.client_names()
        groups = {entry["group_id"]: entry["group_name"] for entry in self.groups(_ALL_CLIENTS)}
        variants: list[dict[str, Any]] = []
        for variant in self.library.prompt_variants(reporting_id):
            payload = variant.model_dump()
            if variant.kind == "client":
                payload["target_name"] = names.get(variant.target_id, variant.target_id)
            elif variant.kind == "groupe":
                payload["target_name"] = groups.get(variant.target_id, variant.target_id)
            else:
                payload["target_name"] = ""
            variants.append(payload)
        return variants

    def save_prompt(
        self,
        reporting_id: str,
        prompt: str,
        *,
        client_id: str = "",
        group_id: str = "",
    ) -> dict[str, Any]:
        """Écrit un prompt par défaut (aucune cible) ou rattaché à une cible."""
        target = PromptTarget(client_id=client_id, group_id=group_id)
        self._check_prompt_target(target)
        saved = self.library.save_prompt(
            reporting_id, prompt, client_id=target.client_id, group_id=target.group_id
        )
        return {
            "id": reporting_id,
            "prompt": saved,
            "chars": len(saved),
            "kind": target.kind,
            "target_id": target.target_id,
        }

    def delete_prompt(
        self, reporting_id: str, *, client_id: str = "", group_id: str = ""
    ) -> dict[str, Any]:
        target = PromptTarget(client_id=client_id, group_id=group_id)
        self._check_prompt_target(target)
        deleted = self.library.delete_prompt(
            reporting_id, client_id=target.client_id, group_id=target.group_id
        )
        if not deleted:
            raise APIError(404, "Aucun prompt associé à cette cible.")
        return {"id": reporting_id, "kind": target.kind, "target_id": target.target_id,
                "deleted": True}

    def _check_prompt_target(self, target: PromptTarget) -> None:
        if target.client_id and target.group_id:
            raise APIError(400, "Un prompt vise soit un client, soit un groupe, pas les deux.")
        if target.client_id and target.client_id not in self.client_names():
            raise APIError(404, f"Client inconnu : {target.client_id}")
        if target.group_id:
            known = {
                entry["group_id"] for entry in self.groups(_ALL_CLIENTS)
            }
            if target.group_id not in known:
                raise APIError(404, f"Groupe inconnu : {target.group_id}")

    def facts(self, scope: ReportScope) -> dict[str, Any]:
        return self.metrics.build(scope)

    def context_payload(
        self,
        reporting_id: str,
        principal: Principal,
        request: GenerateRequest | None = None,
    ) -> ContextResponse:
        """Tout ce qui serait envoyé au modèle, affiché tel quel dans l'interface."""
        definition = self.library.load(reporting_id)
        settings = self.ai_settings()
        scope = self.scope(definition, principal, request)
        resolved = self.prompt_for(
            reporting_id, scope.client_id, str((request or GenerateRequest()).group_id or "")
        )
        prompt_file = resolved["prompt"]
        facts = self.facts(scope)
        sections = tuple(definition.context.sections) if definition.context.sections else None
        rendered = context_module.render(
            facts, max_chars=int(settings["max_context_chars"]), sections=sections
        )
        slides = definition.narrative_slides()
        system = prompting.system_prompt(
            prompt_file,
            rendered["text"],
            language=definition.language,
            audience=definition.audience,
        )
        return ContextResponse(
            reporting_id=definition.id,
            client_id=scope.client_id,
            group_id=str((request or GenerateRequest()).group_id or ""),
            period_label=str((facts.get("period") or {}).get("label", "")),
            as_of=str((facts.get("period") or {}).get("as_of", "")),
            facts=facts,
            context_text=rendered["text"],
            chars=rendered["chars"],
            truncated=rendered["truncated"],
            prompt=prompt_file,
            prompt_source=resolved["source"],
            system_prompt=system,
            slides=prompting.slide_briefs(slides),
        )

    # ------------------------------------------------------------ Génération

    def generate(
        self,
        reporting_id: str,
        principal: Principal,
        request: GenerateRequest,
    ) -> GenerationResponse:
        """Génère le deck d'un seul client.

        Un `group_id` dans la demande est refusé ici : la production pour tous
        les clients d'un groupe passe par `generate_group`, qui produit un deck
        par client (le `group_id` y sert à résoudre le prompt du groupe).
        """
        if str(request.group_id or "").strip():
            raise APIError(
                400,
                "Génération de groupe : utilisez la génération groupée "
                "(un deck par client) plutôt que la génération d'un client.",
            )
        return self._generate_one(reporting_id, principal, request)

    def generate_group(
        self,
        reporting_id: str,
        principal: Principal,
        request: GenerateRequest,
    ) -> GroupGenerationResponse:
        """Génère un deck pour chaque client visible du groupe demandé."""
        started = time.perf_counter()
        group_id = str(request.group_id or "").strip()
        if not group_id:
            raise APIError(400, "Aucun groupe de clients indiqué.")
        # `group` filtre déjà les clients hors périmètre de l'utilisateur.
        group = self.group(group_id, principal)
        members = list(group["client_ids"])
        known = self.client_names()
        rights_skipped = [
            client_id
            for client_id in self._group_members(group_id)
            if client_id not in members and client_id in known
        ]
        warnings: list[str] = []
        if rights_skipped:
            warnings.append(
                f"{len(rights_skipped)} client(s) du groupe hors de votre périmètre "
                "n'ont pas été générés."
            )
        if not members:
            raise APIError(400, f"Le groupe « {group['group_name']} » ne contient aucun client accessible.")

        runs: list[GenerationResponse] = []
        errors: list[dict[str, str]] = []
        for client_id in members:
            per_client = request.model_copy(update={"client_id": client_id, "group_id": group_id})
            try:
                runs.append(self._generate_one(reporting_id, principal, per_client))
            except APIError as exc:
                logger.warning("Génération du client %s impossible : %s", client_id, exc.message)
                errors.append({"client_id": client_id, "error": exc.message})
            except Exception as exc:  # pragma: no cover - garde-fou : un client ne bloque pas le lot
                logger.exception("Génération du client %s en échec", client_id)
                errors.append({"client_id": client_id, "error": str(exc)})
        return GroupGenerationResponse(
            reporting_id=reporting_id,
            group_id=group_id,
            group_name=group["group_name"],
            total=len(group["client_ids"]) + len(rights_skipped),
            generated=len(runs),
            failed=len(errors),
            skipped_client_ids=rights_skipped,
            runs=runs,
            errors=errors,
            warnings=warnings,
            elapsed_seconds=round(time.perf_counter() - started, 2),
            ok=not errors,
        )

    def _group_members(self, group_id: str) -> list[str]:
        """Tous les clients du groupe, sans filtre de périmètre."""
        members: list[str] = []
        for record in self.repository.records(GROUPS_DATASET):
            if str(record.get("group_id", "") or "").strip() != str(group_id or "").strip():
                continue
            client_id = str(record.get("client_id", "") or "").strip()
            if client_id and client_id not in members:
                members.append(client_id)
        return members

    def _generate_one(
        self,
        reporting_id: str,
        principal: Principal,
        request: GenerateRequest,
    ) -> GenerationResponse:
        started = time.perf_counter()
        definition = self.library.load(reporting_id)
        settings = self.ai_settings()

        scope = self.scope(definition, principal, request)
        resolved = self.prompt_for(reporting_id, scope.client_id, str(request.group_id or ""))
        prompt_file = resolved["prompt"]
        facts = self.facts(scope)
        sections = tuple(definition.context.sections) if definition.context.sections else None
        rendered = context_module.render(
            facts, max_chars=int(settings["max_context_chars"]), sections=sections
        )

        warnings: list[str] = list(self.library.warnings(definition))
        if not _aum_of(facts):
            warnings.append(
                "Aucune position trouvée pour ce périmètre : le deck sera généré vide."
            )

        narratives: dict[str, str] = {}
        results: dict[str, SlideResult] = {
            slide.id: SlideResult(id=slide.id, layout=str(slide.layout), title=slide.title)
            for slide in definition.slides
        }
        for slide in definition.slides:
            if slide.narrative:
                results[slide.id].narrative_source = "vide"

        if request.use_ai and definition.narrative_slides():
            narrated = self.narrate(definition, prompt_file, rendered["text"], settings)
            narratives = narrated["slides"]
            for slide_id, text in narratives.items():
                if slide_id in results:
                    results[slide_id].narrative = text
                    results[slide_id].narrative_source = "ia"
                    results[slide_id].verification = SlideVerification(**narrated["verification"][slide_id])
            warnings.extend(narrated["warnings"])
            if narrated["error"]:
                for slide_id in narrated.get("failed", []):
                    if slide_id in results:
                        results[slide_id].narrative_source = "erreur"
                        results[slide_id].error = narrated["error"]
        elif definition.narrative_slides():
            if request.use_ai:
                warnings.append("Narration désactivée pour cette génération.")
            else:
                warnings.append("Narration non demandée (génération sans IA).")
            for slide in definition.narrative_slides():
                results[slide.id].narrative_source = "desactivee"

        template_path = self.library.template_path(reporting_id)
        builder = DeckBuilder(
            str(template_path) if template_path.is_file() else None,
            brand=definition.brand.model_dump(),
        )
        as_of = str((facts.get("period") or {}).get("as_of", ""))
        try:
            payload = builder.render(definition, facts, narratives, as_of=as_of)
        except APIError:
            raise
        except Exception as exc:
            logger.exception("PPTX rendering failed")
            raise APIError(500, f"Génération du PPTX impossible : {exc}") from exc

        # Le deck est produit : ce qui suit est un contrôle de cohérence. Un défaut
        # d'écriture des métadonnées n'annule pas le livrable déjà rendu en mémoire.
        try:
            return self._persist(
                definition=definition,
                facts=facts,
                scope=scope,
                payload=payload,
                results=results,
                warnings=warnings,
                context_chars=rendered["chars"],
                request=request,
                prompt_source=resolved["source"],
                elapsed=time.perf_counter() - started,
            )
        except OSError as exc:
            logger.exception("Unable to persist the generated deck")
            raise APIError(
                500,
                f"Le PPTX a été produit mais n'a pas pu être enregistré : {exc}",
            ) from exc

    def narrate(
        self,
        definition: ReportingDefinition,
        prompt_file: str,
        context_text: str,
        settings: dict[str, Any],
    ) -> dict[str, Any]:
        """Narration par lots, avec vérification numérique de chaque commentaire.

        La narration est découpée en petits lots : un modèle 3B local reste
        nettement plus fiable quand il doit remplir deux ou trois clés JSON plutôt
        qu'une dizaine.
        """
        slides = definition.narrative_slides()
        empty: dict[str, Any] = {
            "slides": {}, "verification": {}, "warnings": [], "error": "", "errors": [], "failed": [],
        }
        if not slides or not context_text:
            return empty
        if self.llm is None:
            return {
                **empty,
                "error": "Service IA non initialisé.",
                "errors": ["Service IA non initialisé."],
                "failed": [slide.id for slide in slides],
            }

        system = prompting.system_prompt(
            prompt_file, context_text, language=definition.language, audience=definition.audience
        )
        registry = verify.build_registry(context_text)
        per_call = max(1, min(4, int(settings["max_slides_per_call"])))
        retries = max(0, int(settings["retries"]))
        max_chars = int(settings["narrative_max_chars"])
        # Un commentaire plus court que le plancher est vraisemblablement une
        # réponse tronquée plutôt qu'un texte volontaire : il ne part pas au client.
        min_chars = max(1, int(settings["narrative_min_chars"]))

        narratives: dict[str, str] = {}
        verification: dict[str, Any] = {}
        warnings: list[str] = []
        errors: list[str] = []
        failed: list[str] = []

        for batch in _chunks(slides, per_call):
            user = prompting.user_prompt(batch, definition)
            messages = [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ]
            batch_error = ""
            for attempt in range(retries + 1):
                try:
                    raw = self.llm.chat(
                        messages,
                        max_tokens=definition.ai.max_tokens or int(settings["max_tokens"]),
                        temperature=(
                            definition.ai.temperature
                            if definition.ai.temperature is not None
                            else float(settings["temperature"])
                        ),
                    )
                except Exception as exc:
                    batch_error = str(exc)
                    logger.warning("Narration IA en echec: %s", exc)
                    break
                parsed = narrative_module.parse_reply(raw, [slide.id for slide in batch])
                # Un lot n'est complet que si chaque slide a un texte exploitable.
                # Une réponse partielle est réutilisée pour ce qu'elle contient, puis
                # les slides manquantes sont redemandées au modèle au tour suivant.
                for slide in batch:
                    text = sanitise(
                        parsed["slides"].get(slide.id, ""),
                        max_chars=max_chars,
                        min_chars=min_chars,
                    )
                    if text:
                        narratives[slide.id] = text
                batch_error = parsed.get("error") or "Réponse du modèle inexploitable."
                if not parsed.get("missing"):
                    break
                if attempt < retries:
                    missing = ", ".join(parsed["missing"])
                    messages.append(
                        {
                            "role": "user",
                            "content": (
                                f"Il manque le commentaire pour : {missing}. "
                                "Réponds uniquement par l'objet JSON demandé, sans texte "
                                f"autour. Clés attendues : {', '.join(s.id for s in batch)}."
                            ),
                        }
                    )
            for slide in batch:
                text = narratives.get(slide.id, "")
                if not text:
                    failed.append(slide.id)
                    continue
                report = verify.check(text, registry)
                verification[slide.id] = {**report, "warning": verify.warning(report)}
                if not report["ok"]:
                    warnings.append(
                        f"Slide « {slide.title or slide.id} » : {verify.warning(report)}"
                    )
            if batch_error and batch_error not in errors:
                errors.append(batch_error)

        # L'échec n'est signalé que si rien n'a pu être écrit : une partie des
        # slides commentée reste un deck livrable avec un avertissement.
        complete_failure = len(failed) == len(slides)
        return {
            "slides": narratives,
            "verification": verification,
            "warnings": warnings,
            "error": (" ; ".join(errors) or "Narration indisponible.") if complete_failure else "",
            "errors": errors,
            "failed": failed,
        }

    # ---------------------------------------------------------------- Sortie

    def _persist(
        self,
        *,
        definition: ReportingDefinition,
        facts: dict[str, Any],
        scope: ReportScope,
        payload: bytes,
        results: dict[str, SlideResult],
        warnings: list[str],
        context_chars: int,
        request: GenerateRequest,
        elapsed: float,
        prompt_source: str = "default",
    ) -> GenerationResponse:
        folder = self.settings.outputs_dir / definition.id
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now()
        as_of = str((facts.get("period") or {}).get("as_of", "") or stamp.strftime("%Y%m%d"))
        client = str((facts.get("client") or {}).get("client_name", "") or scope.client_id or "client")
        slug = _slug(f"{client}-{definition.id}-{as_of}")[:80]
        filename = Path(request.output_name.strip()).name or ""
        if not filename:
            filename = f"{slug}-{stamp.strftime('%H%M%S')}.pptx"
        if not filename.lower().endswith(".pptx"):
            filename = f"{filename}.pptx"
        target = folder / filename
        target.write_bytes(payload)

        run = GenerationResponse(
            id=f"{stamp.strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6]}",
            reporting_id=definition.id,
            filename=filename,
            download_url=f"/api/runs/{definition.id}/{filename}",
            created_at=stamp.isoformat(timespec="seconds"),
            elapsed_seconds=round(elapsed, 2),
            client_id=scope.client_id,
            group_id=str(request.group_id or ""),
            period_label=str((facts.get("period") or {}).get("label", "")),
            as_of=as_of,
            slides=list(results.values()),
            facts=facts,
            context_chars=context_chars,
            prompt_source=prompt_source,  # type: ignore[arg-type]
            engine=self.llm.model_status() if self.llm is not None else {},
            warnings=warnings,
            ok=not any(result.error for result in results.values()),
        )
        self._write_sidecar(target, run)
        record = run.model_dump()
        self._runs.insert(0, record)
        del self._runs[RUN_HISTORY_LIMIT:]
        return run

    def _write_sidecar(self, target: Path, run: GenerationResponse) -> None:
        sidecar = target.with_suffix(".json")
        try:
            sidecar.write_text(
                json.dumps(run.model_dump(), ensure_ascii=False, indent=2, default=str),
                encoding="utf-8",
            )
        except OSError:
            logger.warning("Unable to write sidecar %s", sidecar)

    # -------------------------------------------------------------- Historique

    def runs(self, reporting_id: str = "", limit: int = 50) -> list[dict[str, Any]]:
        # L'historique n'a pas besoin des faits complets : seuls le résumé et les
        # avertissements sont affichés, que la génération vienne de la mémoire ou du disque.
        known = {record["filename"] for record in self._runs if not reporting_id or record["reporting_id"] == reporting_id}
        records = [
            {**record, "facts": _facts_summary(record.get("facts") or {})}
            for record in self._runs
            if not reporting_id or record["reporting_id"] == reporting_id
        ]
        if len(records) >= limit:
            return records[:limit]
        for record in self._history_from_disk():
            if record["filename"] in known:
                continue
            if reporting_id and record["reporting_id"] != reporting_id:
                continue
            records.append(record)
        records.sort(key=lambda record: str(record.get("created_at", "")), reverse=True)
        return records[:limit]

    def _history_from_disk(self) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        root = self.settings.outputs_dir
        if not root.is_dir():
            return records
        for sidecar in sorted(root.glob("*/*.json"), key=lambda path: path.stat().st_mtime, reverse=True):
            try:
                data = json.loads(sidecar.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(data, dict) and data.get("filename"):
                # L'historique n'a pas besoin des faits complets : seuls le résumé
                # et les avertissements sont affichés.
                data["facts"] = _facts_summary(data.get("facts") or {})
                records.append(data)
        return records

    def run(self, reporting_id: str, filename: str) -> dict[str, Any]:
        safe = Path(filename).name
        for record in self.runs(reporting_id, limit=500):
            if record.get("filename") == safe:
                return record
        raise APIError(404, "Génération introuvable.")

    def output_path(self, reporting_id: str, filename: str) -> Path:
        safe = Path(filename).name
        if not safe.lower().endswith(".pptx"):
            raise APIError(400, "Nom de fichier invalide.")
        target = (self.settings.outputs_dir / reporting_id / safe).resolve()
        root = (self.settings.outputs_dir / reporting_id).resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise APIError(400, "Nom de fichier invalide.") from exc
        if not target.is_file():
            raise APIError(404, "Fichier généré introuvable.")
        return target

    # ------------------------------------------------------------- Reportings

    def reportings(self) -> list[dict[str, Any]]:
        return [reference.model_dump() for reference in self.library.list()]

    def reporting_detail(self, reporting_id: str) -> dict[str, Any]:
        return self.library.detail(reporting_id).model_dump()

    def save_definition(self, reporting_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        definition = self.library.save_definition(reporting_id, payload)
        return definition.model_dump()

    def create_reporting(self, reporting_id: str, name: str, copy_template: str = "") -> dict[str, Any]:
        definition = self.library.create(
            reporting_id, name, copy_template_from=copy_template or None
        )
        self.install_template(reporting_id)
        return definition.model_dump()

    def delete_reporting(self, reporting_id: str) -> None:
        self.library.delete(reporting_id)

    def install_template(self, reporting_id: str, brand: dict[str, Any] | None = None) -> Path:
        """Écrit un template PWM par défaut dans le dossier du reporting.

        Le fichier est modifiable à la main ensuite : c'est la charte de la
        maison qui doit primer, pas le code.
        """
        definition = self.library.load(reporting_id)
        target = self.library.template_path(reporting_id)
        target.parent.mkdir(parents=True, exist_ok=True)
        presentation = templates_module.build_default_template(
            brand or definition.brand.model_dump()
        )
        presentation.save(str(target))
        return target

    def template_bytes(self, reporting_id: str) -> bytes:
        path = self.library.template_path(reporting_id)
        if not path.is_file():
            try:
                self.install_template(reporting_id)
            except OSError as exc:
                raise APIError(500, f"Template illisible : {exc}") from exc
        try:
            return path.read_bytes()
        except OSError as exc:
            raise APIError(500, f"Template illisible : {exc}") from exc

    # -------------------------------------------------------------- Moteur IA

    def ai_settings(self) -> dict[str, Any]:
        return ai_config.load(self.settings.base_dir)

    def update_ai_settings(self, payload: dict[str, Any]) -> dict[str, Any]:
        saved = ai_config.save(self.settings.base_dir, payload)
        if self.llm is not None:
            # Un changement de n_ctx ou de modèle invalide le modèle en cache.
            self.llm.unload()
        return saved

    def ai_status(self) -> dict[str, Any]:
        status = (
            self.llm.model_status()
            if self.llm is not None
            else {
                "backend": "",
                "loaded": False,
                "available": False,
                "error": "Service IA non initialisé.",
            }
        )
        status["models"] = ai_config.list_models(
            self.settings.base_dir, self.config.load().get("gguf_path", "")
        )
        return status

    def warmup(self) -> dict[str, Any]:
        if self.llm is None:
            raise APIError(503, "Service IA non initialisé.")
        started = time.perf_counter()
        self.llm.warmup()
        return {"ok": True, "seconds": round(time.perf_counter() - started, 1),
                "engine": self.llm.model_status()}


def _chunks(items: Sequence[Any], size: int) -> list[list[Any]]:
    return [list(items[index: index + size]) for index in range(0, len(items), size)]


def _aum_of(facts: dict[str, Any]) -> float:
    """Actif total du périmètre ; 0 quand le client n'a aucune position."""
    try:
        return float((facts.get("kpis") or {}).get("aum_total") or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _slug(value: str) -> str:
    safe = "".join(char if char.isalnum() or char in "-_" else "-" for char in str(value))
    while "--" in safe:
        safe = safe.replace("--", "-")
    return safe.strip("-") or "reporting"


def _facts_summary(facts: dict[str, Any]) -> dict[str, Any]:
    """Version allégée des faits pour l'historique : KPI, période, allocation."""
    kpis = facts.get("kpis") or {}
    return {
        "period": facts.get("period") or {},
        "client": facts.get("client") or {},
        "kpis": {key: kpis.get(key) for key in (
            "aum_total", "portfolio_cum_return", "benchmark_cum_return", "alpha",
            "sharpe", "nb_positions", "cash_pct",
        )},
        "allocations": {"asset_class": (facts.get("allocations") or {}).get("asset_class", [])},
    }
