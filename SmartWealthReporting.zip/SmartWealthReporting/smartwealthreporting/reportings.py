"""Bibliothèque des reportings : un dossier autonome par reporting.

```
reportings/
└── monthly_client_review/
    ├── definition.json   # structure des slides, KPI, graphiques, charte
    ├── prompt.md         # consignes IA par défaut (ton, audience, règles)
    ├── prompts/          # prompts associés à un client ou à un groupe
    │   ├── client-C001.md
    │   └── group-famille-lambert.md
    └── template.pptx     # charte graphique : slides modèles aux formes nommées
```

Ajouter un reporting = créer un dossier. Aucun code à modifier : l'API et
l'interface découvrent les dossiers au démarrage de chaque requête.

Un prompt peut être rattaché à une cible : un client ou un groupe de clients.
La résolution (client > groupe > défaut) vit dans `services.prompt_for` ;
cette bibliothèque ne fait que lire et écrire les fichiers.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote

from pydantic import ValidationError

from .errors import APIError
from .schemas import PromptVariant, ReportingDefinition, ReportingDetail, ReportingRef

ID_PATTERN = re.compile(r"^[a-z0-9_\-]+$")

#: Sous-dossier des prompts ciblés (client ou groupe).
PROMPT_VARIANTS_DIR = "prompts"
#: Préfixe de fichier par type de cible. `default` reste `prompt.md`.
PROMPT_PREFIXES: dict[str, str] = {"client": "client", "groupe": "group"}
#: Longueur maximale d'un identifiant de cible (client ou groupe).
TARGET_MAX_LENGTH = 100


class ReportingLibrary:
    """Découverte, lecture et écriture des dossiers de reporting."""

    def __init__(self, base_dir: Path) -> None:
        self.base_dir = Path(base_dir).resolve()
        self.root = self.base_dir / "reportings"

    # ------------------------------------------------------------ Parcours

    def ids(self) -> list[str]:
        if not self.root.is_dir():
            return []
        return sorted(
            entry.name
            for entry in self.root.iterdir()
            if entry.is_dir() and (entry / "definition.json").is_file()
        )

    def folder(self, reporting_id: str) -> Path:
        identifier = str(reporting_id or "").strip()
        if not ID_PATTERN.match(identifier):
            raise APIError(400, "Identifiant de reporting invalide (a-z, 0-9, - et _).")
        folder = (self.root / identifier).resolve()
        try:
            folder.relative_to(self.root.resolve())
        except ValueError as exc:  # pragma: no cover - garde-fou traversée de chemin
            raise APIError(400, "Identifiant de reporting invalide.") from exc
        if not folder.is_dir():
            raise APIError(404, f"Reporting inconnu : {identifier}")
        return folder

    def exists(self, reporting_id: str) -> bool:
        try:
            self.folder(reporting_id)
        except APIError:
            return False
        return True

    # ------------------------------------------------------------ Lecture

    def definition_path(self, reporting_id: str) -> Path:
        return self.folder(reporting_id) / "definition.json"

    def load(self, reporting_id: str) -> ReportingDefinition:
        path = self.definition_path(reporting_id)
        try:
            with path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
        except json.JSONDecodeError as exc:
            raise APIError(
                422, f"definition.json invalide pour « {reporting_id} » : {exc.msg} (ligne {exc.lineno})"
            ) from exc
        except OSError as exc:
            raise APIError(500, f"definition.json illisible pour « {reporting_id} » : {exc}") from exc
        if not isinstance(raw, dict):
            raise APIError(422, f"definition.json doit contenir un objet JSON ({reporting_id}).")
        # Le nom du dossier fait foi : c'est lui qui porte les routes, les
        # téléchargements et le dossier de sortie. Un `id` divergent dans le
        # fichier serait une source d'incohérence silencieuse.
        raw["id"] = reporting_id
        try:
            definition = ReportingDefinition(**raw)
        except ValidationError as exc:
            details = "; ".join(
                f"{'.'.join(str(part) for part in error['loc'])}: {error['msg']}"
                for error in exc.errors()
            )
            raise APIError(422, f"definition.json invalide pour « {reporting_id} » : {details}") from exc

        identifiers = [slide.id for slide in definition.slides]
        duplicates = {name for name in identifiers if identifiers.count(name) > 1}
        if duplicates:
            raise APIError(
                422,
                f"definition.json : identifiant de slide dupliqué ({', '.join(sorted(duplicates))}).",
            )
        if not definition.slides:
            raise APIError(422, f"definition.json : le reporting « {reporting_id} » n'a aucune slide.")
        return definition

    def prompt_path(self, reporting_id: str) -> Path:
        return self.folder(reporting_id) / "prompt.md"

    def load_prompt(self, reporting_id: str) -> str:
        path = self.prompt_path(reporting_id)
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return ""
        except OSError as exc:
            raise APIError(500, f"prompt.md illisible pour « {reporting_id} » : {exc}") from exc

    # ------------------------------------------- Prompts ciblés (client/groupe)

    def variant_path(self, reporting_id: str, kind: str, target_id: str = "") -> Path:
        """Chemin du fichier de prompt d'une cible (`client` ou `groupe`).

        L'identifiant de la cible est encodé dans le nom du fichier
        (`client-C001.md`, `group-maison%20lille.md`) : le contenu reste un
        Markdown lisible et éditable à la main, comme `prompt.md`.
        """
        prefix = PROMPT_PREFIXES.get(str(kind or ""))
        if prefix is None:
            raise APIError(400, f"Type de cible de prompt invalide : « {kind} ».")
        identifier = str(target_id or "").strip()
        if not identifier:
            raise APIError(400, "Cible du prompt absente (client_id ou group_id).")
        if len(identifier) > TARGET_MAX_LENGTH:
            raise APIError(
                400, f"Cible du prompt trop longue ({TARGET_MAX_LENGTH} caractères maximum)."
            )
        return (
            self.folder(reporting_id)
            / PROMPT_VARIANTS_DIR
            / f"{prefix}-{quote(identifier, safe='')}.md"
        )

    def has_variant(self, reporting_id: str, kind: str, target_id: str = "") -> bool:
        return self.variant_path(reporting_id, kind, target_id).is_file()

    def load_variant(self, reporting_id: str, kind: str, target_id: str = "") -> str:
        path = self.variant_path(reporting_id, kind, target_id)
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return ""
        except OSError as exc:
            raise APIError(500, f"Prompt associé illisible ({path.name}) : {exc}") from exc

    def save_variant(self, reporting_id: str, kind: str, target_id: str, prompt: str) -> str:
        path = self.variant_path(reporting_id, kind, target_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write(path, str(prompt or "").strip() + "\n")
        return self.load_variant(reporting_id, kind, target_id)

    def delete_variant(self, reporting_id: str, kind: str, target_id: str) -> bool:
        """Supprime le prompt d'une cible ; `False` s'il n'existait pas."""
        path = self.variant_path(reporting_id, kind, target_id)
        if not path.is_file():
            return False
        try:
            path.unlink()
        except OSError as exc:
            raise APIError(500, f"Prompt associé non supprimable ({path.name}) : {exc}") from exc
        return True

    def prompt_variants(self, reporting_id: str) -> list[PromptVariant]:
        """Inventaire des prompts du dossier : défaut + variantes client/groupe."""
        folder = self.folder(reporting_id)
        prompts_dir = folder / PROMPT_VARIANTS_DIR
        variants: list[PromptVariant] = [
            PromptVariant(
                kind="default",
                target_id="",
                filename="prompt.md",
                chars=len(self.load_prompt(reporting_id)),
                modified_at=_modified_at(self.prompt_path(reporting_id)),
            )
        ]
        if not prompts_dir.is_dir():
            return variants
        for path in sorted(prompts_dir.glob("*.md")):
            entry = _parse_variant_name(path.stem)
            if entry is None:
                continue
            kind, target_id = entry
            variants.append(
                PromptVariant(
                    kind=kind,  # type: ignore[arg-type]
                    target_id=target_id,
                    filename=str(Path(PROMPT_VARIANTS_DIR) / path.name),
                    chars=len(_read_text(path)),
                    modified_at=_modified_at(path),
                )
            )
        return variants

    def template_path(self, reporting_id: str) -> Path:
        return self.folder(reporting_id) / "template.pptx"

    def has_template(self, reporting_id: str) -> bool:
        return self.template_path(reporting_id).is_file()

    # ------------------------------------------------------------ Écriture

    def save_prompt(
        self,
        reporting_id: str,
        prompt: str,
        *,
        client_id: str = "",
        group_id: str = "",
    ) -> str:
        """Enregistre un prompt : `prompt.md` ou une variante client/groupe.

        Les deux cibles sont exclusives : un prompt appartient à un seul client
        ou à un seul groupe, jamais aux deux.
        """
        if client_id and group_id:
            raise APIError(400, "Un prompt vise soit un client, soit un groupe, pas les deux.")
        if group_id:
            return self.save_variant(reporting_id, "groupe", group_id, prompt)
        if client_id:
            return self.save_variant(reporting_id, "client", client_id, prompt)
        path = self.prompt_path(reporting_id)
        _atomic_write(path, str(prompt or "").strip() + "\n")
        return self.load_prompt(reporting_id)

    def delete_prompt(self, reporting_id: str, *, client_id: str = "", group_id: str = "") -> bool:
        """Retire le prompt d'une cible. Le défaut revient à un `prompt.md` vide."""
        path = self.prompt_path(reporting_id)
        if group_id:
            return self.delete_variant(reporting_id, "groupe", group_id)
        if client_id:
            return self.delete_variant(reporting_id, "client", client_id)
        if not path.is_file():
            return False
        _atomic_write(path, "\n")
        return True

    def save_definition(self, reporting_id: str, payload: dict[str, Any]) -> ReportingDefinition:
        payload = dict(payload or {})
        payload["id"] = reporting_id
        # On relit par le modèle : une définition invalide n'est jamais persistée.
        try:
            ReportingDefinition(**payload)
        except ValidationError as exc:
            details = "; ".join(
                f"{'.'.join(str(part) for part in error['loc'])}: {error['msg']}"
                for error in exc.errors()
            )
            raise APIError(422, f"Définition invalide : {details}") from exc
        _atomic_write(
            self.definition_path(reporting_id),
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        )
        return self.load(reporting_id)

    def create(
        self,
        reporting_id: str,
        name: str = "",
        *,
        copy_template_from: str | None = None,
    ) -> ReportingDefinition:
        identifier = str(reporting_id or "").strip()
        if not ID_PATTERN.match(identifier):
            raise APIError(400, "Identifiant de reporting invalide (a-z, 0-9, - et _).")
        folder = self.root / identifier
        if folder.exists():
            raise APIError(409, f"Le reporting « {identifier} » existe déjà.")
        folder.mkdir(parents=True, exist_ok=True)

        definition = ReportingDefinition(
            id=identifier,
            name=name.strip() or identifier.replace("_", " ").title(),
            description="Nouveau reporting privé wealth management.",
            slides=[
                {
                    "id": "cover",
                    "layout": "cover",
                    "title": "{{client_name}}",
                    "subtitle": "{{period_label}}",
                },
                {"id": "commentary", "layout": "narrative", "title": "Commentaire", "narrative": True,
                 "focus": "2 à 3 phrases de synthèse pour le client."},
            ],
        )
        self.save_definition(identifier, definition.model_dump())
        self.save_prompt(
            identifier,
            "Tu es un gestionnaire de patrimoine privé. Rédige en français, "
            "de façon claire et factuelle, pour un client non spécialiste.\n",
        )
        if copy_template_from and self.has_template(copy_template_from):
            shutil.copyfile(self.template_path(copy_template_from), self.template_path(identifier))
        return self.load(identifier)

    def delete(self, reporting_id: str) -> None:
        folder = self.folder(reporting_id)
        shutil.rmtree(folder)

    # --------------------------------------------------------------- Vue

    def list(self) -> list[ReportingRef]:
        references: list[ReportingRef] = []
        for identifier in self.ids():
            references.append(self.reference(identifier))
        return references

    def reference(self, reporting_id: str) -> ReportingRef:
        definition = self.load(reporting_id)
        prompt_chars = len(self.load_prompt(reporting_id))
        variants = self.prompt_variants(reporting_id)
        return ReportingRef(
            id=definition.id,
            name=definition.name,
            description=definition.description,
            version=definition.version,
            audience=definition.audience,
            slides=len(definition.slides),
            narrative_slides=len(definition.narrative_slides()),
            has_template=self.has_template(reporting_id),
            prompt_chars=prompt_chars,
            prompt_variants=sum(1 for variant in variants if variant.kind != "default"),
            modified_at=_modified_at(self.folder(reporting_id)),
        )

    def detail(self, reporting_id: str) -> ReportingDetail:
        definition = self.load(reporting_id)
        return ReportingDetail(
            definition=definition,
            prompt=self.load_prompt(reporting_id),
            template_path=str(self.template_path(reporting_id)),
            variants=self.prompt_variants(reporting_id),
            warnings=self.warnings(definition),
        )

    def warnings(self, definition: ReportingDefinition) -> list[str]:
        """Points d'attention affichés dans l'interface avant génération."""
        warnings: list[str] = []
        if not self.has_template(definition.id):
            warnings.append(
                "Template PPTX absent : un template par défaut sera utilisé "
                "(généré à la volée, sans charte)."
            )
        if not self.load_prompt(definition.id).strip():
            warnings.append("prompt.md vide : la narration utilisera des consignes par défaut.")
        if not definition.narrative_slides():
            warnings.append("Aucune slide à narration : le modèle ne sera pas appelé.")
        if not definition.default_client_id and not any(
            kpi.key for slide in definition.slides for kpi in slide.kpis
        ):
            warnings.append("Aucun client par défaut : précisez le client à la génération.")
        return warnings


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temp_path.open("w", encoding="utf-8") as handle:
            handle.write(content)
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError):
        return ""


def _parse_variant_name(stem: str) -> tuple[str, str] | None:
    """Relit `client-C001` / `group-famille` → (« client »|« groupe », cible)."""
    for kind, prefix in PROMPT_PREFIXES.items():
        if stem.startswith(f"{prefix}-"):
            target_id = unquote(stem[len(prefix) + 1:])
            return (kind, target_id) if target_id else None
    return None


def _modified_at(folder: Path) -> str:
    try:
        return datetime.fromtimestamp(folder.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
    except OSError:
        return ""
