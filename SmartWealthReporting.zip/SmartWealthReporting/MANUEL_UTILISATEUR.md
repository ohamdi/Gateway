# Manuel utilisateur - SmartWealthReporting

**Version** : 1.0  
**Date** : 21 octobre 2026  
**Audience** : Gestionnaires de patrimoine, analystes, administrateurs

## Table des matières

- [1. Présentation générale](#1-présentation-générale)
- [2. Connexion et authentification](#2-connexion-et-authentification)
- [3. Onglet Reportings](#3-onglet-reportings)
- [4. Onglet Données](#4-onglet-données)
- [5. Onglet Générations](#5-onglet-générations)
- [6. Onglet Paramétrage](#6-onglet-paramétrage)
- [7. Onglet Moteur IA](#7-onglet-moteur-ia)
- [8. Onglet Utilisateurs (Administrateurs uniquement)](#8-onglet-utilisateurs-administrateurs-uniquement)
- [9. Bonnes pratiques](#9-bonnes-pratiques)
- [10. FAQ et dépannage](#10-faq-et-dépannage)

---

## 1. Présentation générale

SmartWealthReporting est une application de génération de rapports PowerPoint pour le Private Wealth Management. L'application fonctionne selon le principe suivant :

- **Les chiffres sont calculés par le serveur** : Actifs sous gestion, performances, allocations, positions, etc. ne sont jamais inventés par l'IA.
- **L'IA ne rédige que les commentaires** : Le modèle local (Llama) se concentre uniquement sur la rédaction narrative des diapositives marquées comme "narratives".
- **Vérification automatique** : Tous les montants cités par l'IA sont vérifiés par rapport aux faits calculés. Les écarts sont signalés avant diffusion au client.
- **Organisation par reporting** : Chaque type de rapport est un dossier autonome dans `reportings/` contenant sa définition, son prompt et son template PowerPoint.

---

## 2. Connexion et authentification

### Se connecter

1. Ouvrez l'application dans votre navigateur
2. Saisissez votre identifiant et votre mot de passe
3. Cliquez sur « Se connecter »

### Types d'utilisateurs

- **Administrateur** (`admin`) : Accès complet à tous les clients, tous les reportings, configuration, et gestion des utilisateurs
- **Utilisateur restreint** (`user`) : Accès limité à un client spécifique (`client_id`). Ne voit et ne génère que les rapports de ce client

Le badge en haut à droite indique votre identifiant et votre rôle.

### Se déconnecter

Cliquez sur « Déconnexion » en haut à droite de l'écran.

---

## 3. Onglet Reportings

L'onglet Reportings est le cœur de l'application. Il permet de gérer les définitions de reporting, les prompts IA et de générer des rapports individuels.

### 3.1 Liste des reportings

Sur la gauche, vous trouvez la liste des reportings disponibles avec :
- **Nom et identifiant** du reporting
- **Nombre de diapositives** (total / narrées)
- **État du template** (présent ou manquant)
- **Nombre de caractères du prompt** et nombre de prompts ciblés
- **Version et date de modification**

### 3.2 Générer un rapport pour un client

1. Sélectionnez un reporting dans la liste
2. Dans le panneau de détail, sélectionnez le **Client** dans le menu déroulant
3. Ajustez les paramètres si nécessaire :
   - **Arrêté au** : Date de valorisation (par défaut selon la configuration)
   - **Période** : Mois / Trimestre / Année / Depuis janvier
   - **Narration IA** : Cocher/décocher pour utiliser ou non le modèle local
4. Cliquez sur « Générer le PPTX »
5. Attendez la fin du calcul et de la narration (quelques secondes à quelques minutes selon la charge du modèle)
6. Téléchargez le fichier PowerPoint généré

### 3.3 Générer un rapport pour un groupe de clients

1. Sélectionnez un reporting
2. Dans « Groupe de clients », sélectionnez un groupe dans le menu déroulant
3. Le bouton devient « Générer pour le groupe »
4. Cliquez pour générer un PowerPoint **par client** du groupe
5. Un tableau récapitulatif s'affiche avec le statut de chaque génération

> **Important** : Quand un groupe est sélectionné, le client individuel est désactivé. Le prompt utilisé est celui du groupe s'il existe, sinon celui par défaut (sauf si un client a son propre prompt prioritaire).

### 3.4 Gérer les prompts IA

L'onglet « Prompt IA » dans le détail du reporting permet de configurer les consignes envoyées au modèle.

#### Principe de priorité

Les prompts sont appliqués selon l'ordre de priorité : **Client > Groupe > Défaut**

- **Prompt par défaut** (`prompt.md`) : S'applique à tous les clients sans prompt ciblé
- **Prompt de groupe** (`prompts/group-<groupe>.md`) : S'applique à tous les membres du groupe (sauf ceux ayant un prompt client)
- **Prompt de client** (`prompts/client-<client>.md`) : Prioritaire sur le prompt de groupe

#### Créer/modifier un prompt ciblé

1. Dans l'onglet « Prompt IA », sélectionnez la cible dans « Prompt associé à » :
   - « Prompt par défaut (prompt.md) »
   - Un groupe dans « Groupes de clients »
   - Un client dans « Clients »
2. Modifiez le texte dans l'éditeur
3. Cliquez sur « Enregistrer »
4. Le badge indique si c'est une « variante enregistrée » ou si le prompt appliqué provient d'un niveau supérieur

#### Supprimer une variante

Si une variante est enregistrée pour la cible sélectionnée, le bouton « Supprimer la variante » devient actif. La suppression fait revenir au niveau de priorité inférieur.

#### Visualiser le contexte envoyé au modèle

Cliquez sur « Voir le contexte envoyé au modèle » pour inspecter :
- Les faits calculés (KPI, allocation, positions, etc.)
- Le prompt système complet
- Les diapositives demandées à la narration
- La source du prompt utilisé

### 3.5 Autres actions

- **Template** : Télécharger le template PowerPoint actuel
- **Template par défaut** : Réinitialiser le template avec le template PWM standard
- **Définition** : Éditer la structure JSON du reporting (avancé)
- **Slides** : Visualiser la liste des diapositives et leurs configurations
- **Retouche** : Demander à l'IA de reformuler un commentaire existant avec vérification automatique

---

## 4. Onglet Données

L'onglet Données permet de visualiser et configurer les sources de données.

### 4.1 Sources de données

Pour chaque dataset configuré, vous voyez :
- **Nom** et format (parquet, csv, xlsx, json)
- **Chemin** du fichier
- **Statut** : nombre de lignes ou « fichier manquant »
- **Colonnes** disponibles
- **Aperçu** : Cliquez sur « Aperçu » pour visualiser les 20 premières lignes

### 4.2 Modifier les chemins

1. Dans « Chemins », modifiez l'adresse du fichier pour chaque dataset
2. Cliquez sur « Enregistrer »
3. La lecture est automatiquement rechargée

### 4.3 Réinitialiser un chemin

Cliquez sur « Chemin par défaut » pour revenir au chemin par défaut défini dans `datasource_config.json`.

### 4.4 Configuration du modèle local

Dans « Modèle local » :
- **Fichier GGUF** : Sélectionnez le modèle à utiliser
- **Backend** : Choisir entre GGUF (llama-cpp-python) ou Llamafile (serveur)
- Cliquez sur « Enregistrer » puis rendez-vous dans l'onglet « Moteur IA » pour charger le modèle

---

## 5. Onglet Générations

L'onglet Générations regroupe le lancement en masse, la gestion des groupes/clients et l'historique.

### 5.1 Lancement en masse

Permet de générer plusieurs reportings pour plusieurs clients/groupes en une seule opération.

#### Sélection

1. **Reportings** : Cochez un ou plusieurs types de rapports à générer
2. **Groupes de clients** : Cochez un ou plusieurs groupes. Tous les membres du groupe seront inclus (dépliés automatiquement)
3. **Clients** : Cochez des clients individuellement. Vous pouvez filtrer par nom/identifiant/groupe avec le champ de recherche
4. **Paramètres** :
   - **Arrêté au** : Date commune à toutes les générations
   - **Période** : Période commune
   - **Utiliser le modèle local** : Activer/désactiver la narration IA

#### Lancement

- La prévisualisation indique : `X reporting(s) × Y client(s) = Z deck(s)`
- Les clients déjà inclus via un groupe sélectionné sont signalés en vert
- Cliquez sur « Lancer le lot »
- La campagne s'exécute en arrière-plan. L'interface suit la progression en temps réel

#### Suivi du lot

Un panneau « Lot » s'affiche avec :
- Progression (barre et compteur)
- Tableau détaillé par (reporting × client) avec état : en attente / en cours / terminé / échec
- Lien de téléchargement pour chaque deck réussi
- Erreurs éventuelles

### 5.2 Clients & groupes

Cette section permet de gérer l'appartenance des clients aux groupes et le statut « exception ».

#### Vue d'ensemble

Un tableau affiche tous les clients visibles avec :
- **Client** : Nom et identifiant
- **Segment**
- **Groupes** : Puces indiquant les groupes d'appartenance. Cliquer sur `×` retire le client du groupe
- **Statut** : « groupe partagé » ou « groupe à lui seul »
- **Exception** : Bouton pour isoler/réintégrer
- **Appartenance** : Menu déroulant pour ajouter le client à un autre groupe

#### Créer un groupe à lui seul (exception)

Un client « exception » constitue son propre groupe isolé et n'hérite plus des prompts des groupes partagés.

1. Trouvez le client dans le tableau
2. Cliquez sur « Isoler » dans la colonne « Exception »
3. Le client devient « groupe à lui seul » et apparaît comme tel dans les listes
4. Vous pouvez lui attribuer un prompt spécifique dans l'onglet « Paramétrage » ou « Reportings »

#### Réintégrer un client exception

1. Cliquez sur « Réintégrer » pour le client isolé
2. Le client retrouve ses groupes partagés (s'ils existent encore dans le fichier `data/client_groups.json`)

#### Ajouter un client à un groupe

1. Sélectionnez le groupe dans le menu déroulant « Ajouter à un groupe… »
2. Si le client était en exception, il sera automatiquement réintégré
3. Le client rejoint le groupe

#### Retirer un client d'un groupe

Cliquez sur le `×` sur la puce du groupe pour retirer le client. S'il ne reste dans aucun groupe et n'est pas en exception, il devient « sans groupe ».

> **Astuce** : Utilisez le filtre « Tous les groupes » pour afficher uniquement les clients d'un groupe spécifique, ou le champ de recherche pour filtrer par nom/identifiant.

### 5.3 Historique des générations

Liste toutes les générations effectuées avec :
- Date/heure
- Reporting et client/groupe
- Source du prompt utilisé
- Période et date d'arrêté
- Actif net et performance
- Contrôles (avertissements éventuels)
- Lien de téléchargement

---

## 6. Onglet Paramétrage

L'onglet « Paramétrage » donne une vue synthétique de **toute la chaîne** : `Client → Groupe → Reporting → Prompt → Template`. Il permet de visualiser d'un coup d'œil quelle logique s'applique à chaque client et d'accéder rapidement aux prompts à corriger.

### 6.1 Synthèse (KPI)

En haut de l'onglet, 4 indicateurs :
- **Clients** : Nombre de clients visibles / nombre sans groupe
- **Groupes** : Nombre total / nombre de groupes à lui seul (exceptions)
- **Reportings** : Nombre total / nombre de prompts ciblés
- **Templates** : « Complets » ou liste des reportings sans template

### 6.2 Matrice des prompts effectifs

Tableau avec une **ligne par client** et une **colonne par reporting**.

Pour chaque cellule, vous voyez :
- **Badge coloré** indiquant la source effective :
  - `client` (vert) : Un prompt spécifique au client est appliqué
  - `groupe` (bleu) : Un prompt de groupe est appliqué
  - `défaut` (gris) : Le prompt par défaut `prompt.md` est appliqué
- **Nom du groupe/client** cible
- **Groupes d'appartenance** du client (avec indication si exception)

**Action** : Cliquez sur le badge pour ouvrir directement ce prompt dans l'onglet « Reportings » et le modifier.

### 6.3 Groupes de clients × reporting

Vue centrée sur les groupes :
- **Membres** du groupe
- **Effectif**
- Pour chaque reporting, indique si le groupe a un « prompt groupe » ou retombe sur « défaut »
- Clic sur « prompt groupe » pour ouvrir et éditer ce prompt

### 6.4 Reportings — prompt, variantes, template

Pour chaque reporting :
- **État du template** : Présent / absent avec lien de téléchargement ou indication
- **Prompt par défaut** : Bouton pour ouvrir `prompt.md`
- **Variantes ciblées** : Tableau listant tous les prompts client/groupe avec :
  - Cible (client ou groupe)
  - Nom de la cible
  - Fichier
  - Taille en caractères
  - Date de modification
  - Bouton « Ouvrir » pour éditer

> **Astuce** : C'est l'onglet idéal pour auditer rapidement la configuration des prompts avant un lancement en masse.

---

## 7. Onglet Moteur IA

Configure et surveille le moteur d'IA local.

### 7.1 État du moteur

Indicateur visuel :
- **Vert** : Modèle chargé et prêt
- **Orange** : Modèle disponible mais non chargé
- **Rouge** : Modèle indisponible

Informations affichées : Backend, nom du modèle, chemin du fichier, URL (si Llamafile)

### 7.2 Charger le modèle

Cliquez sur « Charger le modèle » pour pré-charger le modèle en mémoire. Recommandé avant un gros lot de générations pour éviter l'attente au premier client.

### 7.3 Paramètres de génération

Ajustez les paramètres selon vos besoins (les valeurs hors bornes sont ignorées) :

| Paramètre | Description | Recommandé |
|-----------|-------------|------------|
| `n_ctx` | Taille du contexte en tokens | 4096 - 8192 |
| `n_threads` | Nombre de threads (0 = automatique) | 0 |
| `n_batch` | Taille du batch | 32 - 512 |
| `temperature` | Créativité du modèle (0 = déterministe, 2 = très créatif) | 0.3 - 0.7 |
| `max_tokens` | Nombre maximum de tokens générés | 1024 - 2048 |
| `max_slides_per_call` | Diapositives narrées par appel | 1 - 3 |
| `narrative_min_chars` / `narrative_max_chars` | Longueur des commentaires | 150-300 / 600-800 |
| `retries` | Nombre de tentatives en cas d'échec | 2 - 3 |

Cliquez sur « Enregistrer » après modification. Le modèle en cache est libéré.

### 7.4 Règle du produit

Le rappel important : **Le modèle local ne produit aucun chiffre.** Seuls les commentaires sont rédigés. Tous les montants cités sont vérifiés contre les faits calculés par le serveur.

---

## 8. Onglet Utilisateurs (Administrateurs uniquement)

Réservé aux administrateurs. Permet de gérer les comptes.

### Créer un utilisateur

1. Cliquez sur « Nouvel utilisateur »
2. Saisissez l'identifiant
3. Saisissez le mot de passe
4. Saisissez le rôle : `admin` ou `user`
5. Pour un utilisateur restreint, saisissez le `client_id` auquel le limiter (vide = tous les clients)
6. Validez

### Modifier un utilisateur

Cliquez sur « Modifier » sur la ligne de l'utilisateur pour changer son mot de passe, son rôle ou son périmètre.

### Supprimer un utilisateur

Cliquez sur « Supprimer » et confirmez. L'utilisateur ne pourra plus se connecter.

---

## 9. Bonnes pratiques

### Organisation des groupes

- **Groupes logiques** : Créez des groupes par famille, par conseiller ou par type de mandat
- **Clients exception** : Utilisez le statut « exception » pour les clients qui doivent avoir un traitement totalement à part (rapport différent, ton différent)
- **Unicité des identifiants** : Les identifiants de groupe ne peuvent pas commencer par `grp-client-` (réservé aux groupes- exceptions)

### Gestion des prompts

- **Démarrer simple** : Commencez avec un bon prompt par défaut dans `prompt.md`, puis affinez par groupe/client au besoin
- **Être factuel** : Demandez au modèle d'être factuel et de ne pas extrapoler. Rappelez-lui qu'il ne doit pas inventer de chiffres
- **Cibler intelligemment** : Utilisez les prompts de groupe pour des familles entières avec le même ton/structure
- **Vérifier la matrice** : Avant un lancement en masse, consultez l'onglet « Paramétrage » pour vous assurer que les bons prompts sont appliqués
- **Adapter le ton** : Différents clients peuvent nécessiter différents tons (familier, institutionnel, synthétique)

### Génération

- **Tester d'abord** : Générez pour un seul client avant un lancement en masse
- **Pré-charger le modèle** : Chargez le modèle dans l'onglet « Moteur IA » avant les gros lots
- **Vérifier les avertissements** : Lisez toujours les avertissements de vérification numérique (montants non trouvés dans les faits)
- **Contrôler l'historique** : Consultez l'onglet « Générations » > « Historique » pour relire les générations passées
- **Lancement en masse** : Utilisez-le pour gagner du temps, mais surveillez le suivi du lot

### Données

- **Sauvegarder avant modification** : Sauvegardez vos fichiers `data/client_groups.json` avant des modifications manuelles importantes
- **Vérifier les formats** : Parquet est recommandé pour les gros volumes, CSV/Excel acceptés
- **Cohérence** : Assurez-vous que les `client_id` dans `client_groups.json` existent bien dans `clients.parquet`

---

## 10. FAQ et dépannage

### Problèmes de connexion

**Problème** : « Session expirée »  
**Solution** : Reconnectez-vous. La session expire après 8 heures par défaut.

**Problème** : Impossible de se connecter  
**Solution** : Vérifiez vos identifiants. En cas de doute, contactez un administrateur.

### Problèmes de génération

**Problème** : « Service IA non initialisé »  
**Solution** : Allez dans l'onglet « Moteur IA » et chargez le modèle, ou désactivez « Utiliser le modèle local ».

**Problème** : Génération très lente au premier client  
**Solution** : Pré-chargez le modèle dans « Moteur IA » > « Charger le modèle » avant de générer.

**Problème** : « Template absent »  
**Solution** : Téléchargez un template ou utilisez « Template par défaut » depuis l'onglet « Reportings ».

**Problème** : Avertissement « montant absent des faits calculés »  
**Solution** : C'est normal si le modèle cite un montant approximatif. Relisez le commentaire. Le serveur n'invente jamais de chiffres, c'est juste une alerte de cohérence.

### Problèmes de groupes

**Problème** : Un client ne voit pas ses groupes dans la génération  
**Solution** : Vérifiez son appartenance dans l'onglet « Générations » > « Clients & groupes ». S'il est en « exception », il forme son propre groupe.

**Problème** : Impossible de modifier un groupe- exception  
**Solution** : Les groupes à lui seul se gèrent via le statut « Exception » du client, pas via les boutons de gestion de groupe.

**Problème** : Un client a plusieurs groupes  
**Solution** : C'est normal. Pour le prompt, c'est le premier groupe trouvé dans l'ordre de résolution qui est utilisé si aucun prompt client n'existe. Pour la génération de groupe, chaque groupe est sélectionné indépendamment.

### Problèmes de données

**Problème** : « Fichier introuvable » dans l'onglet Données  
**Solution** : Corrigez le chemin dans l'onglet « Données » ou remettez le fichier à sa place.

**Problème** : Clients manquants dans les listes  
**Solution** : Vérifiez que l'utilisateur a le bon périmètre. Un utilisateur restreint ne voit que son `client_id`.

### Performance

**Problème** : Lancement en masse bloque l'interface  
**Solution** : C'est normal, la campagne tourne en arrière-plan. Vous pouvez changer d'onglet, l'état est mis à jour automatiquement.

**Problème** : Timeout ou erreur lors d'un gros lot  
**Solution** : Réduisez la taille du lot ou assurez-vous que le modèle est bien chargé et dispose de suffisamment de ressources (RAM/GPU).

---

## Annexes

### Structure des fichiers

```
SmartWealthReporting/
├── data/                      # Données sources
│   ├── clients.parquet
│   ├── client_groups.json    # Appartenance clients/groupes
│   ├── holdings.parquet
│   └── ...
├── reportings/               # Un dossier par reporting
│   └── <reporting_id>/
│       ├── definition.json  # Structure des diapositives
│       ├── prompt.md        # Prompt par défaut
│       ├── prompts/         # Prompts ciblés
│       │   ├── client-*.md
│       │   └── group-*.md
│       └── template.pptx    # Template PowerPoint
├── outputs/                  # Rapports générés
└── static/index.html         # Interface web
```

### Format de `client_groups.json`

```json
[
  {"group_id": "grp-famille-dupont", "group_name": "Famille Dupont", "client_id": "C001"},
  {"group_id": "grp-famille-dupont", "group_name": "Famille Dupont", "client_id": "C002"},
  {"group_id": "grp-client-C003", "group_name": "Martin (groupe à lui seul)", "client_id": "C003", "is_exception": true}
]
```

Pour un client en exception, ajoutez `"is_exception": true`. L'application peut aussi gérer cela via l'interface.

### Raccourcis utiles

- **Actualiser** : Les boutons « Actualiser » permettent de recharger les données sans recharger la page
- **Filtrage** : Utilisez les champs de recherche dans « Générations » pour trouver rapidement clients/groupes
- **Navigation rapide** : Depuis l'onglet « Paramétrage », cliquez sur un badge pour aller directement éditer le prompt concerné

---

*Ce manuel reflète l'état actuel de l'application au 21 octobre 2026.*
