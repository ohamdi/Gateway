"""Nouveaux tests : groupes de clients et prompts associés à un client / un groupe.

Les règles sont claires :
- `client > groupe > défaut` pour le prompt effectif
- Génération pour un groupe : `POST /reportings/<id>/generate-group` produit un
  deck par client, en utilisant le prompt du groupe s'il existe
"""

from __future__ import annotations

import pytest

from smartwealthreporting.errors import APIError
from smartwealthreporting.schemas import GenerateRequest
from smartwealthreporting.services import ApplicationService, _ALL_CLIENTS


# ------------------------------------------------------------------- Prompt bibliothèque
def test_save_prompt_for_a_client_is_stored_in_prompts_dir(library):
    saved = library.save_prompt("test_review", "Prompt specific au client C001", client_id="T001")

    assert saved == "Prompt specific au client C001\n"
    assert library.has_variant("test_review", "client", "T001")
    assert "Prompt specific au client C001" in library.load_variant("test_review", "client", "T001")
    assert library.prompt_variants("test_review")[0].kind == "default"
    assert library.prompt_variants("test_review")[1].kind == "client"
    assert library.prompt_variants("test_review")[1].target_id == "T001"


def test_prompt_variants_lists_default_and_targets(library):
    library.save_prompt("test_review", "Client", client_id="T001")
    library.save_prompt("test_review", "Groupe", group_id="grp-test")
    variants = library.prompt_variants("test_review")

    kinds = [v.kind for v in variants]
    assert "default" in kinds
    assert "client" in kinds
    assert "groupe" in kinds


def test_delete_prompt_variant(library):
    library.save_prompt("test_review", "Groupe", group_id="grp-test")
    assert library.has_variant("test_review", "groupe", "grp-test")

    removed = library.delete_prompt("test_review", group_id="grp-test")
    assert removed is True
    assert not library.has_variant("test_review", "groupe", "grp-test")


def test_prompt_variant_rejects_two_targets(library):
    with pytest.raises(APIError) as exc:
        library.save_prompt("test_review", "X", client_id="T001", group_id="grp-test")
    assert exc.value.status_code == 400


def test_variant_path_encodes_the_target_id(library, tmp_path):
    p = library.variant_path("test_review", "client", "T-001/A")
    assert "T-001%2FA.md" in str(p)
    # Le dossier prompts doit contenir le fichier
    # écriture
    library.save_prompt("test_review", "hi", client_id="T-001/A")
    assert library.load_variant("test_review", "client", "T-001/A") == "hi\n"


# ------------------------------------------------------------------ Groupes (service)
def test_groups_are_listed_with_their_members(service: ApplicationService, admin):
    groups = service.groups(admin)

    grp = next(g for g in groups if g["group_id"] == "grp-test")
    assert set(grp["client_ids"]) >= {"T001", "T002"}
    assert grp["count"] == 2


def test_groups_hide_clients_out_of_scope(service: ApplicationService, restricted):
    groups = service.groups(restricted)

    # restricted n'a accès qu'à T001
    grp = next(g for g in groups if g["group_id"] == "grp-test")
    assert set(grp["client_ids"]) == {"T001"}
    assert grp["count"] == 1

    grp_solo = next(g for g in groups if g["group_id"] == "grp-solo")
    assert grp_solo["client_ids"] == ["T001"]


def test_unknown_group_is_a_404(service: ApplicationService, admin):
    with pytest.raises(APIError) as exc:
        service.group("grp-unknown", admin)
    assert exc.value.status_code == 404


def test_prompt_priority_client_over_group_over_default(service: ApplicationService):
    library = service.library
    library.save_prompt("test_review", "Groupe prompt", group_id="grp-test")
    library.save_prompt("test_review", "Client prompt", client_id="T001")

    assert service.prompt_for("test_review", client_id="T001")["prompt"] == "Client prompt\n"
    assert service.prompt_for("test_review", client_id="T001")["source"] == "client"


def test_group_prompt_applies_through_membership(service: ApplicationService):
    service.library.save_prompt("test_review", "Groupy", group_id="grp-test")
    # T002 belongs to grp-test
    res = service.prompt_for("test_review", client_id="T002")
    assert res["prompt"] == "Groupy\n"
    assert res["source"] == "groupe"


def test_prompt_targets_validation(service: ApplicationService):
    with pytest.raises(APIError):
        service.save_prompt("test_review", "x", client_id="T999")

    with pytest.raises(APIError):
        service.save_prompt("test_review", "x", group_id="grp-unknown")


def test_scope_uses_the_first_group_member_for_context(service: ApplicationService, admin):
    from smartwealthreporting.schemas import GenerateRequest

    scope = service.scope(service.library.load("test_review"), admin, GenerateRequest(group_id="grp-test"))
    assert scope.client_id  # first accessible member


# ---------------------------------------------------------------------- Génération groupe
def test_generate_group_produces_one_deck_per_client(service: ApplicationService, admin):
    res = service.generate_group(
        "test_review",
        admin,
        GenerateRequest(group_id="grp-test", use_ai=False),
    )
    assert res.total == 2
    assert res.generated == 2
    assert res.failed == 0
    assert len(res.runs) == 2
    assert {r.client_id for r in res.runs} >= {"T001", "T002"}


def test_generate_group_uses_the_group_prompt(service: ApplicationService, admin):
    service.library.save_prompt("test_review", "Prompt de groupe", group_id="grp-test")
    res = service.generate_group(
        "test_review",
        admin,
        GenerateRequest(group_id="grp-test", use_ai=False),
    )
    for r in res.runs:
        assert r.prompt_source == "groupe"


def test_generate_group_keeps_going_when_one_client_fails(service: ApplicationService, admin, monkeypatch):
    original = service._generate_one

    def fail_for_T002(reporting_id, principal, request):
        if request.client_id == "T002":
            raise APIError(503, "simulated failure")
        return original(reporting_id, principal, request)

    monkeypatch.setattr(service, "_generate_one", fail_for_T002)
    res = service.generate_group(
        "test_review",
        admin,
        GenerateRequest(group_id="grp-test", use_ai=False),
    )
    assert res.generated == 1
    assert res.failed == 1
    assert any(e["client_id"] == "T002" for e in res.errors)
    assert res.ok is False


def test_generate_refuses_a_group_id(service: ApplicationService, admin):
    with pytest.raises(APIError) as exc:
        service.generate("test_review", admin, GenerateRequest(group_id="grp-test"))
    assert exc.value.status_code == 400


def test_generate_group_with_unknown_group_is_a_404(service: ApplicationService, admin):
    with pytest.raises(APIError):
        service.generate_group("test_review", admin, GenerateRequest(group_id="unknown"))


def test_generate_group_restricted_user_skips_foreign_clients(service: ApplicationService, restricted):
    res = service.generate_group(
        "test_review",
        restricted,
        GenerateRequest(group_id="grp-test", use_ai=False),
    )
    assert res.generated == 1
    assert {r.client_id for r in res.runs} == {"T001"}
    assert "T002" in res.skipped_client_ids or res.skipped_client_ids == ["T002"]


def test_prompt_variant_noop_works(service: ApplicationService):
    res = service.prompt_variant("test_review")
    assert res["kind"] == "default"
    assert res["source"] == "default"
    assert "prompt" in res
