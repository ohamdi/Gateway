# SmartPMS — Desktop (CustomTkinter)

Version bureau de l'application SmartPMS : mêmes données Parquet, mêmes
calculs et mêmes règles d'accès que l'application web, sans serveur ni
navigateur. Le paquet Python `smartpms` du projet voisin `../Smart-pms` est
réutilisé tel quel ; rien n'est modifié dans ce projet.

## Lancement

```bash
cd Smart-pmsCTK
python3 -m pip install -r requirements.txt
python3 app_desktop.py
```

Le dossier `../Smart-pms` doit rester à côté de `Smart-pmsCTK` (le paquet
`smartpms` et `excel_export.py` y sont importés).

## Comptes par défaut

| Utilisateur | Mot de passe | Rôle |
|-------------|--------------|------|
| `admin` | `admin123` | administrateur (tous les fonds, gestion des utilisateurs) |
| `hamdi` | `hamdi123` | utilisateur sans association de fonds (écran vide par conception) |
| `toto` | `toto123` | utilisateur |

Un compte non administrateur ne voit que les fonds associés à son nom, son UG
ou son gérant dans `users_portfolios.parquet`.

## Onglets

- **Tableau de bord** — KPI, cartes de fonds, allocation par secteur, classe
  d'actif et pays, top 10 positions.
- **Positions** — filtres (fonds, recherche, catégorie, secteur, pays, devise),
  tri par colonne, export CSV.
- **Liquidités** — soldes par fonds/devise, tri, export CSV.
- **Opérations** — historique, filtres par type et dates, tri, export CSV.
- **Transactions** — opérations par date de négociation, export CSV.
- **Pre-trade** — contrôle des contraintes, création/édition/activation/
  suppression des contraintes.
- **Assistant IA** — chat local (GGUF ou Llamafile), niveaux de détail,
  graphiques et tableaux calculés côté application.
- **Reporting** — synthèse par période, export CSV et Excel.
- **Source de données** — chemins des fichiers Parquet, modèle GGUF et
  Llamafile ; enregistrés dans `datasource_config.json`.
- **Utilisateurs** — réservé aux administrateurs : création, modification,
  suppression, association de fonds.

## Données et configuration

Tout est local à ce dossier :

- `*.parquet` : copie des données de `../Smart-pms` (fonds, positions,
  opérations, liquidités, contraintes, ESG, exclusions, inventaires,
  utilisateurs).
- `datasource_config.json` : chemins relatifs des fichiers et chemins absolus
  du modèle GGUF / Llamafile. Modifiable depuis l'onglet « Source de données ».

Les exports utilisent une boîte de dialogue « Enregistrer sous » ; le CSV est
en UTF-8 avec point-virgule (compatible Excel français).

## Assistant IA

L'IA est facultative. Si `llama-cpp-python` n'est pas installé ou si le modèle
GGUF est absent, l'application reste utilisable et l'onglet indique
« absent ». Le modèle est chargé à la demande, puis déchargé via le bouton
prévu à cet effet.
