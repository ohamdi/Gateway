"""Tickets d'anomalie : stockage local (JSON) et agrégats pour l'interface.

Un ticket capitalise le suivi d'une anomalie de données : sujet, statut,
priorité, assignation, échéance et lien éventuel vers le contrôle d'origine.
Le stockage est un simple fichier JSON, écrit de façon atomique, afin que le
suivi survive aux redémarrages sans base de données ni migration.

Le module est volontairement sans dépendance à pandas : il ne manipule qu'une
liste de dictionnaires, ce qui le rend utilisable partout (API, démo, tests).
"""

from __future__ import annotations

import json
import os
import re
import threading
import uuid
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Iterable

#: Statuts proposés (l'interface les utilise aussi pour les filtres).
STATUSES: tuple[str, ...] = ("Ouvert", "En cours", "En attente", "Résolu", "Fermé")
#: Statuts considérés comme « en cours de traitement ».
ACTIVE_STATUSES: tuple[str, ...] = ("Ouvert", "En cours", "En attente")
PRIORITIES: tuple[str, ...] = ("Basse", "Normale", "Haute", "Critique")
#: Sujets proposés par défaut (champ libre : toute autre valeur est acceptée).
SUBJECTS: tuple[str, ...] = (
    "ISIN manquant",
    "ISIN en doublon",
    "Cours incohérent",
    "Devise incohérente",
    "Maturité dépassée",
    "Produit structuré",
    "Référentiel incomplet",
    "Rattachement incorrect",
    "Autre",
)

UNSPECIFIED = "Non renseigné"

#: Colonnes du tableau des tickets (affichage dynamique côté interface).
COLUMNS: tuple[dict[str, Any], ...] = (
    {"key": "id", "label": "N° ticket"},
    {"key": "sujet", "label": "Sujet"},
    {"key": "statut", "label": "Statut"},
    {"key": "priorite", "label": "Priorité"},
    {"key": "assigne", "label": "Assigné à"},
    {"key": "code_valeur", "label": "Code valeur"},
    {"key": "libelle", "label": "Libellé", "wrap": True},
    {"key": "source", "label": "Contrôle source", "wrap": True},
    {"key": "date_creation", "label": "Créé le"},
    {"key": "date_echeance", "label": "Échéance"},
    {"key": "description", "label": "Description", "wrap": True},
)

#: Champs d'un ticket, dans l'ordre d'affichage + traçabilité.
FIELDS: tuple[str, ...] = tuple(column["key"] for column in COLUMNS)
_TEXT_FIELDS: tuple[str, ...] = tuple(field for field in FIELDS if field != "id")

MONTH_LABELS: tuple[str, ...] = (
    "Janv.",
    "Févr.",
    "Mars",
    "Avr.",
    "Mai",
    "Juin",
    "Juil.",
    "Août",
    "Sept.",
    "Oct.",
    "Nov.",
    "Déc.",
)


def default_path(base_dir: Path) -> Path:
    """Emplacement par défaut du fichier de tickets d'un projet."""
    return Path(base_dir) / "data" / "tickets.json"


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _parse_date(value: Any) -> date | None:
    """Date ISO (``AAAA-MM-JJ`` ou horodatage) → objet ``date``."""
    text = _text(value)
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()
    except ValueError:
        try:
            return datetime.strptime(text[:10], "%Y-%m-%d").date()
        except ValueError:
            return None


def _clean_record(record: dict[str, Any]) -> dict[str, Any]:
    """Normalise un enregistrement : seuls les champs connus sont conservés."""
    cleaned = {field: _text(record.get(field)) for field in FIELDS}
    if not cleaned["statut"]:
        cleaned["statut"] = STATUSES[0]
    if not cleaned["priorite"]:
        cleaned["priorite"] = PRIORITIES[1]
    return cleaned


def _next_id(records: Iterable[dict[str, Any]]) -> str:
    highest = 0
    for record in records:
        match = re.match(r"TKT-(\d+)$", _text(record.get("id")))
        if match:
            highest = max(highest, int(match.group(1)))
    return f"TKT-{highest + 1:04d}"


def _counts(values: Iterable[str], limit: int | None = None) -> list[dict[str, Any]]:
    counter: Counter[str] = Counter(_text(value) or UNSPECIFIED for value in values)
    items = [{"label": label, "count": int(count)} for label, count in counter.most_common()]
    if limit is not None and len(items) > limit:
        head = items[:limit]
        head.append({"label": "Autres", "count": int(sum(item["count"] for item in items[limit:]))})
        return head
    return items


class TicketStore:
    """Lecture/écriture atomique d'un fichier JSON de tickets."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._lock = threading.RLock()

    # -- lecture / écriture ------------------------------------------------
    def _read(self) -> list[dict[str, Any]]:
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return []
        records = data.get("tickets") if isinstance(data, dict) else data
        if not isinstance(records, list):
            return []
        return [_clean_record(record) for record in records if isinstance(record, dict)]

    def _write(self, records: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
        payload = {"version": 1, "updated": datetime.now().isoformat(timespec="seconds"), "tickets": records}
        try:
            with temp.open("w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            os.replace(temp, self.path)
        finally:
            temp.unlink(missing_ok=True)

    # -- opérations --------------------------------------------------------
    def all(self) -> list[dict[str, Any]]:
        with self._lock:
            return self._read()

    def replace_all(self, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Réécrit intégralement le stock (utilisé par la génération de démo)."""
        with self._lock:
            cleaned = [_clean_record(record) for record in records]
            self._write(cleaned)
            return cleaned

    def get(self, ticket_id: str) -> dict[str, Any] | None:
        with self._lock:
            for record in self._read():
                if record["id"] == ticket_id:
                    return record
        return None

    def create(self, values: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            records = self._read()
            record = {field: _text(values.get(field)) for field in _TEXT_FIELDS}
            record["id"] = _next_id(records)
            if not record["date_creation"]:
                record["date_creation"] = date.today().isoformat()
            record = _clean_record(record)
            record["date_maj"] = datetime.now().isoformat(timespec="seconds")
            records.append(record)
            self._write(records)
            return record

    def update(self, ticket_id: str, values: dict[str, Any]) -> dict[str, Any] | None:
        with self._lock:
            records = self._read()
            for index, record in enumerate(records):
                if record["id"] != ticket_id:
                    continue
                updated = dict(record)
                for key, value in values.items():
                    if key in FIELDS and key != "id" and value is not None:
                        updated[key] = _text(value)
                updated = _clean_record(updated)
                updated["date_maj"] = datetime.now().isoformat(timespec="seconds")
                records[index] = updated
                self._write(records)
                return updated
        return None

    def delete(self, ticket_id: str) -> bool:
        with self._lock:
            records = self._read()
            kept = [record for record in records if record["id"] != ticket_id]
            if len(kept) == len(records):
                return False
            self._write(kept)
            return True

    # -- requêtes ----------------------------------------------------------
    def query(
        self,
        *,
        search: str = "",
        statuses: list[str] | None = None,
        subjects: list[str] | None = None,
        priorities: list[str] | None = None,
        assignees: list[str] | None = None,
        sort: str = "date_creation",
        order: str = "desc",
    ) -> list[dict[str, Any]]:
        statuses = [value for value in (statuses or []) if value]
        subjects = [value for value in (subjects or []) if value]
        priorities = [value for value in (priorities or []) if value]
        assignees = [value for value in (assignees or []) if value]
        needle = (search or "").strip().lower()

        result: list[dict[str, Any]] = []
        for record in self._read():
            if statuses and record["statut"] not in statuses:
                continue
            if subjects and (_text(record["sujet"]) or UNSPECIFIED) not in subjects:
                continue
            if priorities and record["priorite"] not in priorities:
                continue
            if assignees and (_text(record["assigne"]) or UNSPECIFIED) not in assignees:
                continue
            if needle:
                haystack = " ".join(record.get(field, "") for field in FIELDS).lower()
                if needle not in haystack:
                    continue
            result.append(record)

        key = sort if sort in FIELDS else "date_creation"
        reverse = str(order).lower() == "desc"
        filled = [record for record in result if _text(record.get(key))]
        empty = [record for record in result if not _text(record.get(key))]
        filled.sort(key=lambda record: _text(record.get(key)), reverse=reverse)
        return filled + empty

    def stats(self) -> dict[str, Any]:
        records = self._read()
        total = len(records)
        today = date.today()
        horizon = today + timedelta(days=7)

        status_counter = Counter(record["statut"] for record in records)
        priority_counter = Counter(record["priorite"] for record in records)
        open_count = sum(count for status, count in status_counter.items() if status in ACTIVE_STATUSES)
        resolved = status_counter.get("Résolu", 0)
        closed = status_counter.get("Fermé", 0)
        in_progress = status_counter.get("En cours", 0)
        critical = sum(
            1
            for record in records
            if record["statut"] in ACTIVE_STATUSES and record["priorite"] == "Critique"
        )

        overdue = 0
        due_soon = 0
        year = today.year
        month_counts: Counter[int] = Counter()
        year_counts: Counter[int] = Counter()
        for record in records:
            created = _parse_date(record["date_creation"])
            if created:
                year_counts[created.year] += 1
                if created.year == year:
                    month_counts[created.month] += 1
            if record["statut"] in ACTIVE_STATUSES:
                due = _parse_date(record["date_echeance"])
                if due is not None:
                    if due < today:
                        overdue += 1
                    elif due <= horizon:
                        due_soon += 1

        by_status = [
            {"label": status, "count": int(status_counter.get(status, 0))}
            for status in STATUSES
        ]
        by_priority = [
            {"label": priority, "count": int(priority_counter.get(priority, 0))}
            for priority in PRIORITIES
        ]
        by_month = [
            {"month": month, "label": MONTH_LABELS[month - 1], "count": int(month_counts.get(month, 0))}
            for month in range(1, 13)
        ]
        by_year = [
            {"year": int(y), "count": int(c)}
            for y, c in sorted(year_counts.items(), reverse=True)
        ]

        return {
            "kpis": {
                "total": total,
                "open": open_count,
                "in_progress": in_progress,
                "resolved": resolved,
                "closed": closed,
                "overdue": overdue,
                "due_soon": due_soon,
                "critical": critical,
            },
            "by_status": by_status,
            "by_priority": by_priority,
            "by_subject": _counts(record["sujet"] for record in records),
            "by_assignee": _counts(record["assigne"] for record in records),
            "by_month": by_month,
            "by_year": by_year,
            "year": year,
        }

    def facets(self) -> dict[str, list[str]]:
        """Valeurs proposées dans les filtres (listes de référence + vues)."""
        records = self._read()
        subjects = {_text(record["sujet"]) for record in records if _text(record["sujet"])}
        assignees = {_text(record["assigne"]) for record in records if _text(record["assigne"])}
        return {
            "statut": list(STATUSES),
            "priorite": list(PRIORITIES),
            "sujet": sorted(subjects | set(SUBJECTS)),
            "assigne": sorted(assignees),
        }
