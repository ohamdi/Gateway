# SmartDataHub

Application web de visualisation du référentiel des titres (**MasterData**), des
**positions** de portefeuille, du pilotage des **contrôles de données** (un
fichier Parquet = un contrôle) et d'**assistant IA local** sur fichier `.gguf`.

Inspirée de l'architecture de [Smart-pms](../Smart-pms) : FastAPI + interface
statique unique (Bootstrap 5 / Chart.js), configuration des sources dans un
JSON, modèle GGUF chargé en mémoire par `llama-cpp-python`.

## Onglets

| Onglet | Contenu |
| --- | --- |
| **Dashboard** | KPI + graphiques : code valeurs par **Asset Group × Security Type** (barres empilées), par *asset group* (bar), par *security type* (doughnut), **créations par mois et par année** (barres groupées), principaux émetteurs, **répartition de la quantité par Asset Group** (doughnut) |
| **MasterData** | Table complète des titres : code valeur, code ISIN, security type, security group, libellé, devise, émetteur, date de création — recherche, filtres, tri, pagination, export CSV |
| **Position** | Positions du portefeuille : account, client, code valeur, ISIN, **libellé** (joint depuis le MasterData), quantity, market value — recherche, filtres (compte / client), tri, pagination, export CSV |
| **Dashboard Control** | Bar chart global (nombre de codes valeur concernés par contrôle) + liste évolutive des contrôles, détail des anomalies dans une fenêtre modale (**colonnes triables**, recherche, pagination, export CSV, graphique par type) |
| **Assistant IA** | Interrogation d'un fichier `.gguf` local, périmètre = données réellement chargées (contexte consultable), réglages de génération |
| **Management ticket** | Suivi des tickets d'anomalie : KPI par sujet / date / statut, graphiques (statut, priorité, sujet, mois), tableau filtrable (statut, sujet, priorité, assigné), création/édition/suppression, export CSV, import des anomalies des contrôles |
| **Datasource** | Emplacement du MasterData, du fichier Positions, **du fichier Tickets**, du dossier des contrôles et du modèle GGUF ; colonnes détectées ; génération du jeu de démo |

## Démarrage

```bash
pip install -r requirements.txt
pip install -r requirements-llm.txt   # optionnel : assistant IA (GGUF)

python -m smartdatahub.demo_data      # jeu de données de démonstration
python app.py                         # http://localhost:5001
```

ou, avec Uvicorn :

```bash
uvicorn smartdatahub.main:app --host 0.0.0.0 --port 5001
```

Variables d'environnement : `SMARTDATAHUB_HOST`, `SMARTDATAHUB_PORT`,
`SMARTDATAHUB_BASE_DIR`, `SMARTDATAHUB_CONFIG_PATH`.

## Configuration

`datasource_config.json` (onglet **Datasource**, écriture atomique) :

```json
{
  "masterdata_path": "data/masterdata.parquet",
  "positions_path": "data/positions.parquet",
  "tickets_path": "data/tickets.parquet",
  "controls_dir": "data/controls",
  "gguf_path": "/home/ohamdi/Models/Ministral-3-3B-Instruct-2512-Q4_K_M.gguf"
}
```

`ai_config.json` (paramètres de génération) : `n_ctx`, `n_threads`, `n_batch`,
`temperature`, `max_tokens`, `top_p`, `repeat_penalty`, `max_context_chars`.

### Colonnes du MasterData

Les colonnes sont reconnues par alias : `codeValeur`, `CODE_VALEUR`,
`code_valeur`, `Code Valeur`… sont tous ramenés à `code_valeur`. Champs
attendus et alias :

| Champ | Alias acceptés |
| --- | --- |
| `code_valeur` | codevaleur, codeval, securitycode, code, ticker, mnemonique |
| `code_isin` | codeisin, isin, isincode |
| `security_type` | securitytype, typevaleur, typesecurite, typeinstrument, type, classe |
| `security_group` | securitygroup, groupeseurite, groupevaleur, groupe, group, category, categorie |
| `libelle` | libelle, designation, intitule, nom, name, label |
| `devise` | devise, currency, monnaie, ccy |
| `emetteur` | emetteur, issuer, societeemetrice, societe, teneur |
| `date_creation` | datecreation, datedecreation, creationdate, datecrea, date |

Le mapping réel est affiché dans l'onglet **Datasource** ; les champs absents
sont signalés sans bloquer l'application.

#### Colonnes supplémentaires (dynamiques)

Toute colonne du fichier qui n'est **pas** reconnue comme champ métier est
affichée automatiquement à la fin de la table de l'onglet **MasterData**, avec
un « ＋ » dans l'en-tête et la mention *supplémentaire* dans l'onglet
**Datasource**. Aucune configuration ni redéploiement : **ajouter une colonne
au Parquet suffit**.

- **Tri** : cliquer l'en-tête de la colonne la trie aussi (côté serveur).
- **Recherche** : les colonnes texte supplémentaires sont incluses dans la
  recherche globale.
- **Export CSV** : les colonnes supplémentaires sont en fin d'en-tête.
- **Libellé** : `secteur_activite` → « Secteur activite », `QuantiteGlobale` →
  « Quantite Globale » (séparateurs et camelCase gérés).
- **Filtres** (type / groupe / devise) et agrégats du dashboard restent
  réservés aux 8 champs métier.
- La démo contient deux colonnes hors standard : `Secteur` et
  `QuantiteGlobale`.

### Colonnes du fichier Positions

L'onglet **Position** lit un second Parquet (`positions_path`), configuré dans
l'onglet **Datasource**. Les colonnes sont reconnues par alias, comme pour le
MasterData :

| Champ | Alias acceptés |
| --- | --- |
| `account` | account, compte, numerocompte, numerodecompte, nocompte, codecompte, ndecompte, portfolio, portefeuille |
| `client` | client, nomclient, clientname, customer, codeclient, clientid, titulaire |
| `code_valeur` | codevaleur, codeval, securitycode, codevaleurinterne, code, ticker, mnemonique |
| `code_isin` | codeisin, isin, isincode |
| `libelle` | libelle, designation, intitule, nom, name, label |
| `quantity` | quantity, quantite, quantites, qty, qte, quantitedetenue, quantitedetenu |
| `market_value` | marketvalue, marketval, valeurmarche, valormarche, valeurdemarche, montantmarche, valorisation, valeur, montant |

Les colonnes sont affichées dans l'ordre **account, client, code valeur, ISIN,
libellé, quantity, market value**. Si le fichier Positions ne contient pas de
libellé, il est **joint automatiquement depuis le MasterData** (par code valeur,
puis par ISIN) : la colonne est donc toujours disponible, y compris pour la
recherche, le tri et l'export CSV. Le panneau Datasource indique
« MasterData » comme origine de ce champ.

Les champs absents sont signalés (sans bloquer l'affichage), toute autre colonne
du fichier est affichée automatiquement en fin de table (marquée « ＋ »), et la
recherche couvre toutes les colonnes texte. Filtres par **compte** et **client**.

La recherche saisie dans l'onglet **MasterData** est aussi appliquée à
l'onglet **Position** : rechercher un code valeur, un ISIN, un libellé ou un
émetteur dans le référentiel filtre les positions du titre correspondant (un
badge « Recherche MasterData » le signale). Le bouton **Positions** de la barre
de filtres MasterData ouvre directement l'onglet avec ce critère. Les filtres
compte/client de Position sont alors réinitialisés afin de ne pas masquer le
résultat. La recherche de l'onglet Position reste modifiable indépendamment ;
son bouton de réinitialisation retire ce critère lié.

### Quantité

Si le MasterData porte une colonne de **quantité globale** par titre
(`quantite`, `QuantiteGlobale`, `quantity`, `qty`, `QTY`, `globale`… — ou tout
nom normalisé commençant par `quantit`), elle est détectée automatiquement et
**sommée par Asset Group** dans le graphique « Répartition de la quantité par
Asset Group » du Dashboard. Aucune configuration : renommer/adapter la colonne
suffit. Si aucune colonne de quantité n'est trouvée, le graphique l'indique.

### Contrôles

Tout fichier `.parquet` déposé dans `controls_dir` devient un contrôle : son
nom de fichier donne le libellé (`controle_2_…` → « Contrôle 2 : … »). La
découverte est **récursive** (les sous-dossiers sont acceptés) et l'extension
est reconnue **sans tenir compte de la casse** (`.parquet`, `.PARQUET`…) : les
fichiers non Parquet sont ignorés et **signalés dans l'onglet Datasource**. Le
décompte porte sur les **codes valeur distincts** du fichier ; si une colonne
de statut existe (`anomalie`, `status`, `conforme`…), seules les lignes
marquées en anomalie sont comptées.

Il n'y a **aucune limite** sur le nombre de contrôles. Dans l'onglet Dashboard
Control, la liste affiche tous les contrôles (recherche locale liste +
graphique) et le graphique ne trace que les **20 plus chargés** — note
« Top 20 sur N » — pour rester lisible. Cliquez une barre ou une ligne pour
ouvrir le détail : les **colonnes du tableau sont triables** (un clic trie par
ordre croissant, un second inverse le sens), quel que soit le type de la
colonne — texte, nombre ou date — et le tri porte sur **toutes** les lignes du
contrôle, pas seulement la page affichée.

### Tickets d'anomalie

Comme le MasterData et les positions, les tickets sont lus depuis un **fichier
Parquet** (`tickets_path`), configuré dans l'onglet **Datasource**. Le fichier
est relu automatiquement dès qu'il change (mtime/taille) : aucun import manuel.
Tant que `tickets_path` est vide ou introuvable, le suivi reste dans
`data/tickets.json` (écriture atomique, enveloppe versionnée
`{version, updated, tickets}`) : pas de base de données.

Le Parquet est importé dans ce fichier JSON, ce qui laisse intactes les
créations/éditions faites dans l'onglet **Management ticket**. S'il contient
une colonne d'identifiant, les tickets sont fusionnés par id (les tickets
saisis dans l'application sont conservés) ; sinon son contenu remplace le suivi.

Les colonnes sont reconnues **par alias, insensible à la casse et aux accents**,
exactement comme pour le MasterData :

| Champ | Exemples de noms acceptés |
| --- | --- |
| N° ticket | `id`, `ticket`, `N° ticket`, `numero` |
| Sujet | `sujet`, `subject`, `motif`, `theme` |
| Statut | `statut`, `status`, `etat` |
| Priorité | `priorité`, `priority`, `urgence` |
| Assigné à | `assigné à`, `assigne`, `responsable` |
| Code valeur | `code valeur`, `code`, `code interne`, `security code` |
| Libellé | `libellé`, `libelle`, `label`, `nom` |
| Contrôle source | `contrôle source`, `source`, `controle` |
| Créé le / Échéance | `crée le`, `date creation`, `échéance`, `due date` |
| Description | `description`, `commentaire`, `note` |

Un ticket dont l'**identifiant existe déjà est mis à jour** (les champs vides
du fichier ne viennent pas écraser les valeurs connues) : **réimporter le même
fichier est idempotent**. Un identifiant absent ou inconnu reçoit un
`TKT-nnnn` unique ; si aucune colonne de création n'est présente, la date du
jour sert de date de saisie. Les énumérations sont canonisées (`ouvert` →
« Ouvert ») et les dates sont normalisées en `AAAA-MM-JJ`. Les cellules vides
pandas (`NaN`, `NaT`) sont stockées comme des chaînes vides.

## API

| Méthode | Route | Rôle |
| --- | --- | --- |
| GET | `/api/dashboard` | agrégats du Dashboard |
| GET | `/api/masterdata` | titres filtrés/triés/paginés (`q`, `type`, `group`, `devise`, `sort`, `order`, `offset`, `limit`) |
| GET | `/api/masterdata/facets` | valeurs distinctes pour les filtres + mapping des colonnes |
| GET | `/api/masterdata/export` | export CSV filtré (séparateur `;`, BOM UTF-8) |
| GET | `/api/positions` | positions filtrées/triées/paginées (`q`, `account`, `client`, `sort`, `order`, `offset`, `limit`) |
| GET | `/api/positions/facets` | valeurs distinctes des comptes et clients + mapping des colonnes |
| GET | `/api/positions/export` | export CSV filtré des positions |
| GET | `/api/controls` | liste des contrôles découverts + total d'anomalies |
| GET | `/api/controls/{id}` | anomalies d'un contrôle (`q`, `sort`, `order`, `offset`, `limit`) |
| GET | `/api/controls/{id}/export` · `/by-type` | export CSV et agrégation par type de sécurité |
| GET/POST | `/api/datasource` | lecture/écriture des emplacements |
| POST | `/api/datasource/demo` | (re)génération des données de démonstration |
| GET | `/api/tickets` · `/stats` · `/facets` | tickets d'anomalie (filtres `statut`, `sujet`, `priorité`, `assigné`, `q`, tri, pagination) |
| GET | `/api/tickets/export` | export CSV filtré des tickets |
| POST | `/api/tickets` · `PUT` · `DELETE /api/tickets/{id}` | création, mise à jour, suppression |
| POST | `/api/tickets/import` | import des anomalies des contrôles (idempotent) |
| POST | `/api/tickets/import-file` | import d'un fichier **Parquet** (corps binaire = le fichier, query `filename`, `replace`) |
| GET | `/api/ai/status` | état du moteur, modèles détectés, réglages |
| GET | `/api/ai/context` | contexte réellement envoyé au modèle |
| POST | `/api/ai/chat` | question/réponse sur les données chargées |
| POST | `/api/ai/warmup` · `/api/ai/unload` | chargement / libération du modèle |
| GET/POST | `/api/ai/config` | réglages de génération |

## Structure

```
SmartDataHub/
├── app.py                    # point d'entrée (uvicorn)
├── datasource_config.json    # emplacements des fichiers
├── requirements.txt          # FastAPI, pandas, pyarrow…
├── requirements-llm.txt      # llama-cpp-python (optionnel)
├── data/
│   ├── masterdata.parquet    # démo : 600 titres
│   ├── positions.parquet     # démo : positions (comptes / clients)
│   └── controls/             # démo : 5 contrôles
├── smartdatahub/
│   ├── main.py               # fabrique FastAPI + services statiques
│   ├── routes.py             # API
│   ├── services.py           # agrégats, requêtes, contexte IA
│   ├── repository.py         # lecture Parquet + détection des colonnes
│   ├── llm.py                # modèle GGUF (chargement paresseux)
│   ├── config.py             # datasource_config.json
│   ├── ai_config.py          # ai_config.json + détection des .gguf
│   └── demo_data.py          # jeu de démonstration (python -m smartdatahub.demo_data)
└── static/index.html         # interface single-page (7 onglets)
```

## Tests

```bash
python -m pytest tests/ -q     # tests métier (62 tests)

# test de bout en bout de l'interface (Playwright + Chromium)
python -m venv .venv-ui && .venv-ui/bin/pip install playwright
.venv-ui/bin/python -m playwright install chromium
.venv-ui/bin/python tests/e2e_ui.py     # 40 contrôles, nécessite un serveur lancé
```
