"""Compatibility entrypoint: python app.py"""

from __future__ import annotations

import os

import uvicorn

from smartwealth.main import app

__all__ = ["app"]


if __name__ == "__main__":
    uvicorn.run(
        app,
        host=os.getenv("SMARTSWEALTH_HOST", "127.0.0.1"),
        port=int(os.getenv("SMARTSWEALTH_PORT", "5100")),
    )
