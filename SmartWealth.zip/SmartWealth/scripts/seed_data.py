"""Generate the deterministic demo dataset used by SmartWealth.

Run from the project root:

    python scripts/seed_data.py

The data is synthetic but internally coherent: mandate AUM equals the sum of
its positions, performance paths end on the current AUM, and a few mandates
are deliberately overweight so the allocation controls have something to flag.
"""

from __future__ import annotations

import json
import random
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
rng = random.Random(20261103)

# ---------------------------------------------------------------------------
# Reference data
# ---------------------------------------------------------------------------

CLIENTS = [
    ("C001", "Sophie Marchand", "Privé", "Paris 8e", "France", "Claire Dubois", "2019-04-15", "Validé"),
    ("C002", "Famille Lambert", "Family Office", "Lyon 6e", "France", "Claire Dubois", "2015-09-02", "Validé"),
    ("C003", "Alexandre Nguyen", "Entrepreneur", "Paris 17e", "France", "Marc Ferrand", "2021-06-21", "Validé"),
    ("C004", "Famille Rossi", "Privé", "Nice", "France", "Marc Ferrand", "2018-02-12", "Validé"),
    ("C005", "Helena Vandenberg", "Institutionnel", "Bruxelles", "Belgique", "Marc Ferrand", "2017-11-05", "Validé"),
    ("C006", "Jean-Pierre Muller", "Privé", "Luxembourg", "Luxembourg", "Sofia Ricci", "2016-07-19", "À revoir"),
    ("C007", "Aisha El Mansouri", "Entrepreneur", "Casablanca", "Maroc", "Sofia Ricci", "2022-03-08", "Validé"),
    ("C008", "Thomas Weber", "Privé", "Genève", "Suisse", "Sofia Ricci", "2020-10-27", "Validé"),
    ("C009", "Fondation Aurore", "Institutionnel", "Paris", "France", "Claire Dubois", "2014-05-30", "Validé"),
    ("C010", "Marco Bianchi", "Privé", "Milan", "Italie", "Marc Ferrand", "2023-09-11", "En attente"),
]

# mandate_id, client_id, name, type, strategy, aum, inception, fee, review, status, risk profile, objective
MANDATES = [
    ("M001", "C001", "Mandat Patrimoine Marchand", "Gestion discrétionnaire", "Équilibré", 1_900_000, "2019-05-20", 0.85, "2026-06-15", "Actif", "Modéré", "Capitalisation long terme et revenus réguliers"),
    ("M002", "C001", "Poche Obligataire", "Gestion conseillée", "Défensif", 1_350_000, "2019-05-20", 0.55, "2026-06-15", "Actif", "Prudent", "Revenus obligataires stables"),
    ("M003", "C002", "Mandat Famille Lambert", "Gestion discrétionnaire", "Défensif", 2_600_000, "2015-10-01", 0.60, "2026-05-20", "Actif", "Prudent", "Transmission et préservation du capital"),
    ("M004", "C002", "Trésorerie Familiale", "Gestion conseillée", "Trésorerie", 700_000, "2015-10-01", 0.35, "2026-05-20", "Actif", "Prudent", "Trésorerie disponible"),
    ("M005", "C003", "Mandat Dynamique Nguyen", "Gestion discrétionnaire", "Dynamique", 3_500_000, "2021-06-21", 0.95, "2026-03-10", "Actif", "Dynamique", "Croissance du capital"),
    ("M006", "C003", "Poche Thématique Innovation", "Conseil en allocation", "Croissance", 1_200_000, "2022-01-15", 0.75, "2026-03-10", "Actif", "Dynamique", "Exposition thématique innovation"),
    ("M007", "C004", "Mandat Famille Rossi", "Gestion discrétionnaire", "Équilibré", 2_400_000, "2018-02-12", 0.80, "2026-02-12", "Actif", "Modéré", "Diversification globale"),
    ("M008", "C004", "Mandat ISR Durable", "Gestion discrétionnaire", "Équilibré", 1_450_000, "2021-09-01", 0.90, "2026-02-12", "Revue annuelle", "Modéré", "Impact social et philanthropie"),
    ("M009", "C005", "Mandat Institutionnel Vandenberg", "Gestion discrétionnaire", "Défensif", 7_500_000, "2017-11-05", 0.45, "2026-04-02", "Actif", "Modéré", "Rendement durable et gouvernance"),
    ("M011", "C006", "Mandat Muller Prudent", "Gestion discrétionnaire", "Défensif", 1_800_000, "2016-07-19", 0.70, "2025-11-10", "Revue annuelle", "Prudent", "Préparation de la retraite"),
    ("M012", "C007", "Mandat Croissance El Mansouri", "Gestion discrétionnaire", "Croissance", 2_200_000, "2022-03-08", 0.90, "2026-07-08", "Actif", "Dynamique", "Croissance et diversification géographique"),
    ("M013", "C008", "Mandat Weber Équilibré", "Gestion discrétionnaire", "Équilibré", 4_200_000, "2020-10-27", 0.80, "2026-08-14", "Actif", "Modéré", "Équilibre rendement / risque"),
    ("M014", "C009", "Mandat Fondation Aurore", "Gestion discrétionnaire", "Équilibré", 5_000_000, "2014-05-30", 0.65, "2026-01-22", "Actif", "Modéré", "Impact social et distribution annuelle"),
    ("M015", "C009", "Poche Obligations Durables", "Gestion conseillée", "Défensif", 2_800_000, "2014-05-30", 0.50, "2026-01-22", "Actif", "Prudent", "Obligations durables"),
    ("M016", "C010", "Mandat Bianchi Dynamique", "Gestion discrétionnaire", "Dynamique", 2_900_000, "2023-09-11", 0.90, "2025-09-11", "Onboarding", "Dynamique", "Croissance internationale et couverture du change"),
]

MODELS = {
    "Trésorerie": {"Monétaire": 85, "Obligations": 15},
    "Défensif": {"Obligations": 55, "Actions": 20, "Monétaire": 10, "Immobilier": 5, "Alternatif": 5, "Or": 5},
    "Équilibré": {"Obligations": 40, "Actions": 40, "Monétaire": 5, "Immobilier": 5, "Alternatif": 5, "Or": 5},
    "Croissance": {"Obligations": 20, "Actions": 60, "Monétaire": 3, "Immobilier": 7, "Alternatif": 7, "Or": 3},
    "Dynamique": {"Obligations": 10, "Actions": 75, "Monétaire": 2, "Immobilier": 5, "Alternatif": 5, "Or": 3},
}

RISK_BANDS = {"Monétaire": 3, "Obligations": 5, "Actions": 5, "Immobilier": 4, "Alternatif": 4, "Or": 3}

# model_id, name, strategy, risk profile, objective
PORTFOLIO_MODELS = [
    ("PM-01", "Modèle Trésorerie", "Trésorerie", "Prudent", "Préserver la liquidité avec un rendement monétaire régulier"),
    ("PM-02", "Modèle Défensif", "Défensif", "Prudent", "Protéger le capital et générer des revenus stables"),
    ("PM-03", "Modèle Équilibré", "Équilibré", "Modéré", "Équilibrer croissance et maîtrise de la volatilité"),
    ("PM-04", "Modèle Croissance", "Croissance", "Dynamique", "Rechercher la croissance à moyen terme"),
    ("PM-05", "Modèle Dynamique", "Dynamique", "Dynamique", "Maximiser la croissance à long terme"),
]

# name, isin, sector, country, currency
UNIVERSE = {
    "Actions": [
        ("Apple Inc", "US0378331005", "Technologie", "États-Unis", "USD"),
        ("Microsoft Corp", "US5949181045", "Technologie", "États-Unis", "USD"),
        ("LVMH", "FR0000121014", "Consommation", "France", "EUR"),
        ("ASML Holding", "NL0010273215", "Semi-conducteurs", "Pays-Bas", "EUR"),
        ("Novo Nordisk", "DK0062498333", "Santé", "Danemark", "DKK"),
        ("Nestlé", "CH0038863350", "Consommation", "Suisse", "CHF"),
        ("SAP SE", "DE0007164600", "Technologie", "Allemagne", "EUR"),
        ("TotalEnergies", "FR0000120271", "Énergie", "France", "EUR"),
        ("Schneider Electric", "FR0000121972", "Industrie", "France", "EUR"),
        ("AstraZeneca", "GB0009895292", "Santé", "Royaume-Uni", "GBP"),
        ("TSMC ADR", "US8740391003", "Semi-conducteurs", "Taïwan", "USD"),
        ("JPMorgan Chase", "US46647H1005", "Finance", "États-Unis", "USD"),
        ("Alphabet Inc", "US02079K3059", "Technologie", "États-Unis", "USD"),
        ("Siemens AG", "DE0007236101", "Industrie", "Allemagne", "EUR"),
    ],
    "Obligations": [
        ("OAT 3,00 % Oct 2031", "FR0000199679", "Souverain", "France", "EUR"),
        ("Bund 2,10 % Août 2032", "DE0001102564", "Souverain", "Allemagne", "EUR"),
        ("BTP 3,50 % 2033", "IT0005518128", "Souverain", "Italie", "EUR"),
        ("Schneider Electric 2,50 % 2031", "FR0010337793", "Entreprises", "France", "EUR"),
        ("Euro Aggregate ETF", "LU1650487413", "Diversifié", "Zone euro", "EUR"),
        ("Green Bond Fund", "LU1984407575", "Diversifié", "Zone euro", "EUR"),
        ("Corporate IG Fund", "FR0013423450", "Entreprises", "Zone euro", "EUR"),
        ("OAT Verte 1,75 % 2039", "FR0013234333", "Souverain", "France", "EUR"),
    ],
    "Monétaire": [
        ("Fonds Monétaire EUR", "FR0000447823", "Monétaire", "Zone euro", "EUR"),
        ("Liquidités EUR", "CASH-EUR", "Trésorerie", "Zone euro", "EUR"),
        ("ETF Overnight", "LU0290358497", "Monétaire", "Zone euro", "EUR"),
    ],
    "Immobilier": [
        ("SCPI Corum", "FR0013236667", "Immobilier", "France", "EUR"),
        ("REIT Europe ETF", "IE00B0M63284", "Immobilier", "Europe", "EUR"),
        ("SCPI Primonial", "FR0013234818", "Immobilier", "France", "EUR"),
    ],
    "Alternatif": [
        ("Private Equity Fund II", "LU1978686608", "Private Equity", "Europe", "EUR"),
        ("Hedge Fund Global Macro", "IE00BYX5MX76", "Alternatif", "Global", "EUR"),
        ("Infrastructure Fund", "LU1904765135", "Infrastructure", "Europe", "EUR"),
    ],
    "Or": [
        ("Gold ETC", "IE00B4BND3602", "Matières premières", "Global", "USD"),
    ],
}

PERF_PARAMS = {
    "Trésorerie": (0.20, 0.12),
    "Défensif": (0.32, 0.85),
    "Équilibré": (0.48, 1.45),
    "Croissance": (0.62, 2.10),
    "Dynamique": (0.72, 2.70),
}


def _positions_for(mandate: tuple) -> list[dict]:
    mandate_id, _client_id, _name, _type, strategy, aum = mandate[:6]
    model = MODELS[strategy]
    # Deliberate drifts so the allocation controls have real breaches to show.
    tilts = {
        "M001": {"Actions": 1.30},
        "M003": {"Obligations": 1.35},
        "M007": {"Actions": 1.55},
        "M013": {"Actions": 1.25},
        "M012": {"Actions": 1.15},
    }
    tilt = tilts.get(mandate_id, {})
    tilted = {ac: w * tilt.get(ac, 1.0) for ac, w in model.items()}
    total = sum(tilted.values())
    weights = {ac: w / total * 100 for ac, w in tilted.items()}

    rows: list[dict] = []
    for asset_class, weight in weights.items():
        universe = UNIVERSE[asset_class]
        n = 1 if weight < 8 else 2 if weight < 25 else 3
        picks = rng.sample(universe, min(n, len(universe)))
        splits = [rng.uniform(0.7, 1.3) for _ in picks]
        split_total = sum(splits)
        for instrument, split in zip(picks, splits):
            name, isin, sector, country, currency = instrument
            value = aum * weight / 100 * split / split_total
            rows.append(
                {
                    "mandate_id": mandate_id,
                    "instrument": name,
                    "isin": isin,
                    "asset_class": asset_class,
                    "sector": sector,
                    "country": country,
                    "currency": currency,
                    "market_value": value,
                }
            )

    # Make the market values add up exactly to the mandate AUM.
    current = sum(r["market_value"] for r in rows)
    factor = aum / current
    for row in rows:
        row["market_value"] = round(row["market_value"] * factor, 2)
    residual = round(aum - sum(r["market_value"] for r in rows), 2)
    rows[-1]["market_value"] = round(rows[-1]["market_value"] + residual, 2)

    for row in rows:
        row["quantity"] = round(row["market_value"] / rng.uniform(45, 420), 2)
        row["price"] = round(row["market_value"] / row["quantity"], 2)
        pnl_pct = rng.uniform(-12, 28) if row["asset_class"] == "Actions" else rng.uniform(-5, 9)
        row["cost_basis"] = round(row["market_value"] / (1 + pnl_pct / 100), 2)
        row["pnl_unrealised"] = round(row["market_value"] - row["cost_basis"], 2)
        row["weight"] = round(row["market_value"] / aum * 100, 2)
        row["status"] = rng.choices(["Active", "En revue", "Suspendue"], weights=[85, 10, 5])[0]
    return rows


def main() -> None:
    DATA.mkdir(parents=True, exist_ok=True)

    clients = pd.DataFrame(
        CLIENTS,
        columns=[
            "client_id", "client_name", "segment", "domicile", "country",
            "fund_manager", "onboarding_date", "kyc_status",
        ],
    )
    clients["base_ccy"] = "EUR"
    clients = clients[
        ["client_id", "client_name", "segment", "domicile", "country", "fund_manager",
         "base_ccy", "onboarding_date", "kyc_status"]
    ]
    clients.to_parquet(DATA / "clients.parquet", index=False)

    mandates = pd.DataFrame(
        MANDATES,
        columns=[
            "mandate_id", "client_id", "mandate_name", "mandate_type", "strategy",
            "aum", "inception_date", "management_fee_pct",
            "last_review", "status", "risk_profile", "objectives",
        ],
    )
    mandates["base_ccy"] = "EUR"
    mandates["fund_manager"] = mandates["client_id"].map({c[0]: c[5] for c in CLIENTS})
    mandates["model_id"] = mandates["strategy"].map({m[2]: m[0] for m in PORTFOLIO_MODELS})
    mandates.insert(1, "mandate_code", "SW-" + mandates["mandate_id"].str[1:])

    holdings: list[dict] = []
    for mandate in MANDATES:
        holdings.extend(_positions_for(mandate))
    holdings_df = pd.DataFrame(holdings)
    holdings_df = holdings_df[
        ["mandate_id", "instrument", "isin", "asset_class", "sector", "country",
         "currency", "quantity", "price", "market_value", "weight", "cost_basis",
         "pnl_unrealised", "status"]
    ]
    holdings_df.to_parquet(DATA / "holdings.parquet", index=False)

    allocation_rows = []
    for mandate in MANDATES:
        for asset_class, target in MODELS[mandate[4]].items():
            band = RISK_BANDS[asset_class]
            allocation_rows.append(
                {
                    "mandate_id": mandate[0],
                    "asset_class": asset_class,
                    "target_pct": target,
                    "min_pct": max(0, target - band),
                    "max_pct": min(100, target + band),
                }
            )
    pd.DataFrame(allocation_rows).to_parquet(DATA / "allocations.parquet", index=False)

    months = pd.date_range("2024-10-31", periods=24, freq="ME")
    perf_rows = []
    ytd_by_mandate: dict[str, float] = {}
    for mandate in MANDATES:
        mandate_id, client_id, _name, _type, strategy, aum = mandate[:6]
        mean, vol = PERF_PARAMS[strategy]
        returns = [round(rng.gauss(mean, vol), 2) for _ in months]
        port_cum = (pd.Series(1 + pd.Series(returns) / 100).cumprod() - 1) * 100
        start_aum = aum / (1 + port_cum.iloc[-1] / 100)
        ytd_returns = [r for r, month in zip(returns, months) if month.year == months[-1].year]
        ytd_by_mandate[mandate_id] = round(
            ((1 + pd.Series(ytd_returns) / 100).prod() - 1) * 100, 2
        )
        for i, month in enumerate(months):
            perf_rows.append(
                {
                    "mandate_id": mandate_id,
                    "client_id": client_id,
                    "date": month,
                    "monthly_return": returns[i],
                    "portfolio_cum": round(port_cum.iloc[i], 2),
                    "aum": round(start_aum * (1 + port_cum.iloc[i] / 100), 2),
                    "period_label": month.strftime("%b %y"),
                }
            )
    pd.DataFrame(perf_rows).to_parquet(DATA / "performance.parquet", index=False)

    mandates["perf_ytd"] = mandates["mandate_id"].map(ytd_by_mandate)
    mandates.to_parquet(DATA / "mandates.parquet", index=False)

    model_rows = []
    model_rng = random.Random(20261104)
    for model_id, model_name, strategy, risk_profile, objectives in PORTFOLIO_MODELS:
        for asset_class, target in MODELS[strategy].items():
            universe = UNIVERSE[asset_class]
            count = 1 if target < 8 else 2 if target < 25 else 3
            picks = model_rng.sample(universe, min(count, len(universe)))
            splits = [model_rng.uniform(0.7, 1.3) for _ in picks]
            split_total = sum(splits)
            for instrument, split in zip(picks, splits):
                name, isin, sector, country, currency = instrument
                model_rows.append(
                    {
                        "model_id": model_id,
                        "model_name": model_name,
                        "strategy": strategy,
                        "risk_profile": risk_profile,
                        "objectives": objectives,
                        "asset_class": asset_class,
                        "instrument": name,
                        "isin": isin,
                        "sector": sector,
                        "country": country,
                        "currency": currency,
                        "weight": round(target * split / split_total, 2),
                    }
                )
    pd.DataFrame(model_rows).to_parquet(DATA / "portfolio_models.parquet", index=False)

    trade_rows = []
    trade_types = ["BUY", "BUY", "SELL", "INTEREST", "FEE", "WITHDRAWAL"]
    start = pd.Timestamp("2026-04-01")
    for mandate in MANDATES:
        mandate_id, client_id, _name, _type, _strategy, aum = mandate[:6]
        positions = holdings_df[holdings_df.mandate_id == mandate_id]
        for n in range(6):
            kind = trade_types[n % len(trade_types)]
            position = positions.sample(1, random_state=rng.randint(1, 10_000)).iloc[0]
            trade_date = start + pd.Timedelta(days=rng.randint(0, 180))
            instrument = position["instrument"]
            if kind == "FEE":
                instrument = "Frais de gestion"
                amount = -round(aum * 0.0075 / 4, 2)
            elif kind == "WITHDRAWAL":
                instrument = "Flux de trésorerie"
                amount = -round(rng.uniform(10_000, 90_000), 2)
            elif kind == "INTEREST":
                instrument = positions[positions.asset_class == "Obligations"].iloc[0]["instrument"]
                amount = round(rng.uniform(1_500, 12_000), 2)
            else:
                amount = round(rng.uniform(8_000, 120_000), 2)
            trade_rows.append(
                {
                    "mandate_id": mandate_id,
                    "client_id": client_id,
                    "date": trade_date.strftime("%Y-%m-%d"),
                    "type": kind,
                    "instrument": instrument,
                    "amount": amount,
                    "status": "En attente" if mandate_id == "M016" and n == 5 else "Exécuté",
                }
            )
    pd.DataFrame(trade_rows).sort_values(["date", "mandate_id"]).to_parquet(
        DATA / "transactions.parquet", index=False
    )

    users = [
        {"username": "demo", "password": "demo", "role": "admin", "display_name": "Demo Advisor"},
        {"username": "conseiller", "password": "conseiller123", "role": "user", "display_name": "Conseiller"},
    ]
    (DATA / "users.json").write_text(json.dumps(users, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"clients      {len(clients)}")
    print(f"mandates     {len(mandates)}")
    print(f"models       {len(PORTFOLIO_MODELS)}")
    print(f"holdings     {len(holdings_df)}")
    print(f"performance  {len(perf_rows)}")
    print(f"transactions {len(trade_rows)}")
    print(f"total AuM    {mandates.aum.sum():,.0f} EUR")


if __name__ == "__main__":
    main()
