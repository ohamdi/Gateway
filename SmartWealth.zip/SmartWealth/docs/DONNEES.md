# SmartWealth — Documentation des données

Ce document décrit l'origine de chaque donnée affichée dans l'application, le rôle des
fichiers Parquet, leurs champs, les règles de validation et les agrégats calculés.

## 1. Principe général

Toutes les données métier affichées proviennent des fichiers Parquet de `data/` (ou des
chemins personnalisés enregistrés dans `datasource_config.json`). Aucune donnée métier
n'est codée en dur dans l'interface.

```text
data/*.parquet
      │
      ▼
Repository (storage.py)          lecture + cache par date de modification
      │
      ▼
WealthService (services.py)      jointures, agrégats, calculs
      │
      ▼
API /api/* (routes.py)           JSON
      │
      ▼
SPA (static/index.html)          rendu, graphiques Chart.js
```

Les seules valeurs non issues des Parquet sont techniques : horodatage de génération,
identifiants de session et libellés de l'interface.

## 2. Fichiers Parquet

| Fichier | Lignes (jeu de démo) | Clé | Rôle |
|---|---:|---|---|
| `clients.parquet` | 10 | `client_id` | Référentiel clients et statut KYC |
| `mandates.parquet` | 15 | `mandate_id` | Mandats, encours, rattachement au modèle, performance YTD |
| `portfolio_models.parquet` | 43 | `model_id` + `isin` | Portefeuilles modèles et leur inventaire |
| `holdings.parquet` | 141 | `mandate_id` + `isin` | Positions réelles par mandat |
| `transactions.parquet` | 90 | — | Mouvements par mandat |
| `performance.parquet` | 360 | `mandate_id` + `date` | Historique mensuel de performance |

Jeu de démonstration : **41 500 000 €** d'encours, **15 mandats**, **10 clients**,
**5 portefeuilles modèles**, période de performance du **31/10/2024 au 30/09/2026**.

### Récapitulatif des champs

- **`clients.parquet`** : `client_id`, `client_name`, `segment`, `domicile`, `country`, `fund_manager`, `base_ccy`, `onboarding_date`, `kyc_status`
- **`mandates.parquet`** : `mandate_id`, `mandate_code`, `client_id`, `mandate_name`, `mandate_type`, `strategy`, `aum`, `inception_date`, `management_fee_pct`, `last_review`, `status`, `risk_profile`, `objectives`, `base_ccy`, `fund_manager`, `model_id`, `perf_ytd`
- **`portfolio_models.parquet`** : `model_id`, `model_name`, `strategy`, `risk_profile`, `objectives`, `asset_class`, `instrument`, `isin`, `sector`, `country`, `currency`, `weight`
- **`holdings.parquet`** : `mandate_id`, `instrument`, `isin`, `asset_class`, `sector`, `country`, `currency`, `quantity`, `price`, `market_value`, `weight`, `cost_basis`, `pnl_unrealised`, `status`
- **`transactions.parquet`** : `mandate_id`, `client_id`, `date`, `type`, `instrument`, `amount`, `status`
- **`performance.parquet`** : `mandate_id`, `client_id`, `date`, `monthly_return`, `portfolio_cum`, `aum`, `period_label`

Le détail de chaque champ (type, caractère obligatoire, usage) figure dans les
sections suivantes.

### 2.1 `clients.parquet`

Référentiel des clients. La colonne `fund_manager` y est dupliquée avec `mandates.parquet` ;
l'onglet ClientMandate utilise celle du client pour le filtre.

| Champ | Type | Obligatoire au chargement | Description / usage |
|---|---|:---:|---|
| `client_id` | string | oui | Identifiant unique du client (`C001`…) |
| `client_name` | string | oui | Nom affiché |
| `segment` | string | oui | `Privé`, `Family Office`, `Entrepreneur`, `Institutionnel` |
| `domicile` | string | oui | Ville / lieu de domiciliation |
| `country` | string | oui | Pays |
| `fund_manager` | string | oui | Gestionnaire du client |
| `base_ccy` | string | oui | Devise de référence (`EUR`) |
| `onboarding_date` | date (`YYYY-MM-DD`) | oui | Date d'entrée en relation |
| `kyc_status` | string | oui | `Validé`, `À revoir`, `En attente` ; alimente les alertes KYC |

### 2.2 `mandates.parquet`

Un enregistrement par mandat. Chaque mandat est rattaché à un portefeuille modèle via
`model_id`. Le code affiché est `mandate_code` (`SW-` + numéro du mandat).

| Champ | Type | Obligatoire au chargement | Description / usage |
|---|---|:---:|---|
| `mandate_id` | string | oui | Identifiant unique du mandat (`M001`…) |
| `mandate_code` | string | utilisé | Code affiché (`SW-001`…) |
| `client_id` | string | utilisé | Lien vers `clients.client_id` |
| `mandate_name` | string | utilisé | Nom du mandat |
| `mandate_type` | string | utilisé | `Gestion discrétionnaire`, `Gestion conseillée`, `Conseil en allocation` |
| `strategy` | string | utilisé | `Trésorerie`, `Défensif`, `Équilibré`, `Croissance`, `Dynamique` |
| `aum` | float | utilisé | Encours du mandat ; base de tous les agrégats d'encours |
| `inception_date` | date (`YYYY-MM-DD`) | utilisé | Date de mise en gestion |
| `management_fee_pct` | float | utilisé | Frais de gestion annuels en % |
| `last_review` | date (`YYYY-MM-DD`) | utilisé | Date de dernière revue |
| `status` | string | utilisé | `Actif`, `Revue annuelle`, `Onboarding` |
| `risk_profile` | string | oui | `Prudent`, `Modéré`, `Dynamique` |
| `objectives` | string | oui | Objectif du mandat |
| `base_ccy` | string | oui | Devise de référence |
| `fund_manager` | string | oui | Gestionnaire du mandat |
| `model_id` | string | oui | Portefeuille modèle rattaché (`PM-01`…`PM-05`) |
| `perf_ytd` | float | oui | Performance YTD en % ; **valeur affichée** pour le YTD |

Règle de validation : au chargement d'un fichier Mandats, `model_id` doit être non vide
et exister dans le fichier Portefeuilles modèles courant.

### 2.3 `portfolio_models.parquet`

Une ligne par instrument et par modèle. Les colonnes de description du modèle
(`model_name`, `strategy`, `risk_profile`, `objectives`) sont répétées sur chaque ligne ;
l'application les déduplique par `model_id`.

| Champ | Type | Obligatoire au chargement | Description / usage |
|---|---|:---:|---|
| `model_id` | string | oui | Identifiant du modèle (`PM-01`…) |
| `model_name` | string | oui | Nom affiché (`Modèle Équilibré`…) |
| `strategy` | string | oui | Stratégie du modèle |
| `risk_profile` | string | oui | Profil de risque du modèle |
| `objectives` | string | oui | Objectif du modèle |
| `asset_class` | string | oui | Classe d'actifs de la ligne |
| `instrument` | string | oui | Nom de l'instrument |
| `isin` | string | oui | Code ISIN |
| `sector` | string | utilisé | Secteur (inventaire du modèle) |
| `country` | string | utilisé | Pays / zone (inventaire du modèle) |
| `currency` | string | utilisé | Devise de l'instrument |
| `weight` | float | oui | Poids de la ligne en % ; la somme par `asset_class` donne l'allocation modèle |

Les poids d'un modèle sont agrégés par `asset_class` à la lecture : c'est cette somme
qui est comparée à l'allocation réelle du mandat.

### 2.4 `holdings.parquet`

Positions réelles, une ligne par instrument et par mandat. La somme des `market_value`
d'un mandat est égale à son `aum`.

| Champ | Type | Obligatoire au chargement | Description / usage |
|---|---|:---:|---|
| `mandate_id` | string | oui | Mandat détenteur |
| `instrument` | string | oui | Nom de l'instrument |
| `isin` | string | oui | Code ISIN |
| `asset_class` | string | oui | `Actions`, `Obligations`, `Monétaire`, `Immobilier`, `Alternatif`, `Or` |
| `sector` | string | oui | Secteur |
| `country` | string | oui | Pays / zone |
| `currency` | string | oui | Devise |
| `quantity` | float | oui | Quantité |
| `price` | float | oui | Prix unitaire |
| `market_value` | float | oui | Valeur de marché ; base de l'allocation réelle |
| `weight` | float | oui | Poids de la position dans le mandat (%) |
| `cost_basis` | float | oui | Prix de revient |
| `pnl_unrealised` | float | oui | P&L latent |
| `status` | string | oui | `Active`, `En revue`, `Suspendue` |

### 2.5 `transactions.parquet`

Mouvements et flux par mandat. Les 10 plus récents sont affichés sur le Dashboard.

| Champ | Type | Obligatoire au chargement | Description / usage |
|---|---|:---:|---|
| `mandate_id` | string | oui | Mandat concerné |
| `client_id` | string | oui | Client concerné |
| `date` | date (`YYYY-MM-DD`) | oui | Date de l'opération |
| `type` | string | oui | `BUY`, `SELL`, `INTEREST`, `FEE`, `WITHDRAWAL` |
| `instrument` | string | oui | Instrument ou libellé du flux |
| `amount` | float | oui | Montant signé (négatif pour une sortie) |
| `status` | string | oui | `Exécuté`, `En attente` |

### 2.6 `performance.parquet`

Historique mensuel, une ligne par mandat et par mois. Sert aux statistiques autres que
le YTD et à la courbe de performance consolidée.

| Champ | Type | Obligatoire au chargement | Description / usage |
|---|---|:---:|---|
| `mandate_id` | string | oui | Mandat |
| `client_id` | string | oui | Client |
| `date` | date (timestamp) | oui | Fin de mois |
| `monthly_return` | float | oui | Rendement mensuel en % |
| `portfolio_cum` | float | oui | Performance cumulée depuis le début de l'historique (%) |
| `aum` | float | oui | Encours de fin de mois |
| `period_label` | string | oui | Libellé court (`Sep 26`) |

La date `as_of` de l'application est la plus grande date de ce fichier.

## 3. Relations entre fichiers

```text
clients.client_id 1 ──── n mandates.client_id
mandates.model_id  n ──── 1 portfolio_models.model_id
mandates.mandate_id 1 ── n holdings.mandate_id
mandates.mandate_id 1 ── n transactions.mandate_id
mandates.mandate_id 1 ── n performance.mandate_id
```

- Un client peut avoir plusieurs mandats.
- Chaque mandat référence exactement un portefeuille modèle.
- Un portefeuille modèle peut être rattaché à plusieurs mandats.
- Les positions, mouvements et performances se rattachent au mandat, jamais directement
  au client.

## 4. Provenance des éléments affichés

| Élément affiché | Origine / calcul |
|---|---|
| Encours d'un mandat | `mandates.aum` |
| Encours d'un client | Somme des `aum` de ses mandats |
| Encours total, KPI et graphiques | Somme des `aum` des mandats |
| Performance YTD d'un mandat | `mandates.perf_ytd` |
| Performance YTD consolidée | Moyenne des `perf_ytd` pondérée par `aum` |
| Performance 12 mois, drawdown, meilleur / pire mois | Recalculés depuis `performance.monthly_return` et `portfolio_cum` |
| Courbe de performance consolidée | `performance.monthly_return × aum`, regroupée par date |
| Allocation réelle par classe | `holdings.market_value` regroupé par `asset_class`, divisé par `aum` |
| Allocation modèle par classe | `portfolio_models.weight` regroupé par `asset_class` |
| Écart (`drift_pct`) | `actual_pct − model_pct` |
| Proposition de rééquilibrage | Écart ≥ 2 points, montant = `abs(drift_pct) / 100 × aum` |
| Inventaire d'un mandat | Lignes de `holdings` du mandat |
| Portefeuille modèle d'un mandat | `mandates.model_id` joint à `portfolio_models` |
| Mandats rattachés à un modèle | `mandates` filtrés par `model_id` |
| Alertes KYC | `clients.kyc_status ≠ Validé` |
| Frais moyens | `mandates.management_fee_pct` pondéré par `aum` |
| Encours par stratégie | `mandates.aum` regroupé par `strategy` |
| Dernières opérations | `transactions` joint à `mandates` et `clients` |
| Nombre de mandats par fund manager / segment / profil | Regroupement de `mandates` (segment via `clients`) |
| Encours par fund manager / segment / profil | Somme de `aum` sur les mêmes regroupements |
| Date de situation (`as_of`) | `max(performance.date)` |

## 5. Onglets et données utilisées

| Onglet | Données |
|---|---|
| **Dashboard & KPI** | `GET /api/kpi` : totaux et regroupements par fund manager, segment et profil |
| **Dashboard** | `/api/dashboard` : encours, performance consolidée, allocation, alertes, opérations |
| **ClientMandate** | `/api/clients`, `/api/mandates`, `/api/mandates/{id}/allocation` |
| **PortfolioModel** | `/api/portfolio-models` : modèles, allocation, inventaire, mandats liés |
| **MandateAllocation** | `/api/mandates/{id}/allocation` : allocation modèle / réelle, écarts, rééquilibrage, positions |
| **Reporting** | `/api/reporting/*` : rapport et export Excel construits depuis les mêmes données |
| **DataSource** | `/api/datasources` : schéma, aperçu, chargement et réinitialisation des Parquet |

## 6. API

| Méthode | Route | Contenu |
|---|---|---|
| `POST` | `/api/login`, `/api/logout` | Session |
| `GET` | `/api/me` | Utilisateur courant |
| `GET` | `/api/dashboard` | Agrégats du Dashboard |
| `GET` | `/api/kpi` | Agrégats serveur du Dashboard & KPI |
| `GET` | `/api/clients`, `/api/clients/{id}` | Clients et mandats |
| `GET` | `/api/mandates`, `/api/mandates/{id}` | Mandats |
| `GET` | `/api/mandates/{id}/allocation` | Allocation, écarts, rééquilibrage, positions |
| `GET` | `/api/portfolio-models` | Modèles, inventaire, mandats liés |
| `GET` | `/api/reporting/catalog` | Types de rapport et mandats |
| `POST` | `/api/reporting/generate` | Rapport JSON |
| `GET` | `/api/reporting/excel` | Export Excel |
| `GET` | `/api/datasources` | État des sources |
| `PUT` | `/api/datasources/{key}` | Chargement d'un chemin personnalisé |
| `DELETE` | `/api/datasources/{key}` | Retour au fichier par défaut |
| `GET` | `/api/datasources/{key}/download` | Téléchargement du Parquet |

Clés de source : `clients`, `mandates`, `models`, `positions`, `movements`, `performance`.

## 7. Chargement et validation des sources

Chaque source est déclarée dans `DATA_SOURCES` (`smartwealth/services.py`) avec :

- son libellé et son fichier par défaut ;
- ses colonnes obligatoires, contrôlées à l'import ;
- éventuellement les colonnes montrées dans l'aperçu DataSource.

À l'enregistrement d'un chemin personnalisé :

1. le fichier doit exister et être un Parquet lisible ;
2. toutes les colonnes obligatoires doivent être présentes ;
3. pour les Mandats, `model_id` doit être non vide et connu du fichier modèles courant ;
4. le chemin est persisté dans `datasource_config.json` (clé `sources`) ;
5. le cache de la source est invalidé et l'application relit le fichier.

Le bouton **Réinitialiser** supprime le chemin personnalisé et revient au fichier de
`data/`.

## 8. Volumes et performance

- `GET /api/kpi` agrège côté serveur et ne renvoie qu'une ligne par fund manager, segment
  ou profil, plus les totaux. Le payload reste donc petit même avec beaucoup de mandats.
- Les autres écrans (`Dashboard`, `ClientMandate`, `PortfolioModel`) chargent encore tous
  les mandats et calculent leurs métriques à la demande. Sur de très gros volumes, la
  prochaine étape est de paginer `/api/mandates` et d'alléger `/api/dashboard`.
- Les fichiers Parquet sont lus en mémoire et mis en cache par date de modification.

## 9. Régénérer le jeu de démonstration

```bash
cd /home/ohamdi/Bureau/Documents/SmartWealth
python scripts/seed_data.py
```

Le script est déterministe et réécrit : clients, mandats, portefeuilles modèles,
positions, performance et transactions. Il ne modifie pas `datasource_config.json`.

## 10. Limites connues

- Données synthétiques de démonstration ; les mots de passe de `data/users.json` sont en
  clair et ne doivent pas être utilisés en production.
- Le YTD affiché vient de `mandates.perf_ytd`. Charger un `performance.parquet`
  personnalisé ne met pas à jour cette colonne : les deux fichiers doivent rester
  cohérents.
- Charger les Mandats avant les Portefeuilles modèles personnalisés peut échouer si les
  `model_id` ne correspondent pas encore.
- Les colonnes utilisées mais non obligatoires (par exemple `aum`, `mandate_name`) ne sont
  pas contrôlées à l'import : un fichier incomplet peut être accepté puis provoquer une
  erreur d'affichage.
