from __future__ import annotations

import io
from datetime import datetime
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .services import REPORT_TYPES, WealthService, _eur, _f, _pct

MONTHS_FR = [
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre",
]

NAVY = "0F2A43"
TEAL = "0E7490"
LIGHT = "EEF4F8"


def _report_type(report_type: str) -> dict[str, str]:
    for item in REPORT_TYPES:
        if item["id"] == report_type:
            return item
    raise ValueError("Type de rapport inconnu.")


def build_report(
    service: WealthService, mandate_id: str, report_type: str = "mandate_review"
) -> dict[str, Any]:
    kind = _report_type(report_type)
    mandate = service.mandate(mandate_id)
    client = service.client(mandate["client_id"]) or {}
    allocation = service.allocation(mandate_id)
    performance = service.performance_series(mandate_id, 12)
    as_of = mandate["as_of"]
    month = MONTHS_FR[int(as_of[5:7]) - 1]
    period = f"{month} {as_of[:4]}"
    breaches = [row for row in allocation["rows"] if row["status"] != "Conforme"]

    if report_type == "performance_review":
        paragraphs = [
            (
                f"Le portefeuille {mandate['mandate_name']} affiche une performance de "
                f"{_pct(mandate['ytd_pct'])} depuis le début de l'année."
            ),
            (
                f"Sur douze mois, la performance ressort à {_pct(mandate['one_year_pct'])}. "
                f"Le drawdown maximal sur la période atteint {mandate['max_drawdown_pct']:.2f} %."
            ),
            (
                f"Le mois le plus favorable a progressé de {mandate['best_month_pct']:.2f} % et "
                f"le plus défavorable a reculé de {mandate['worst_month_pct']:.2f} %. "
                f"Le profil de risque du mandat est « {mandate['risk_profile']} »."
            ),
        ]
    elif report_type == "allocation_review":
        if breaches:
            detail = " ; ".join(
                f"{row['asset_class']} {row['actual_pct']:.1f} % pour une cible de "
                f"{row['target_pct']:.1f} % ({row['drift_pct']:+.1f} pts)"
                for row in breaches
            )
            allocation_text = (
                f"{len(breaches)} classe(s) d'actifs sortent de leur bande de tolérance : {detail}."
            )
        else:
            allocation_text = "Toutes les classes d'actifs se situent dans leur bande de tolérance."
        paragraphs = [
            (
                f"Le portefeuille {mandate['mandate_name']} est investi sur "
                f"{len(allocation['rows'])} classes d'actifs pour un encours de {_eur(mandate['aum'])}. "
                f"{allocation_text}"
            ),
            (
                f"L'écart absolu le plus important concerne {mandate['drift_asset_class']} "
                f"({mandate['max_drift_pct']:+.1f} pts). Le statut de conformité du mandat est "
                f"« {mandate['compliance']} »."
            ),
            (
                "Les propositions de rééquilibrage privilégient un retour progressif dans les bandes, "
                "en tenant compte des frais de transaction et de la liquidité des supports."
            ),
        ]
    else:
        paragraphs = [
            (
                f"Le portefeuille {mandate['mandate_name']} de {client.get('client_name', mandate['client_name'])} "
                f"représente un encours de {_eur(mandate['aum'])} en stratégie {mandate['strategy']}, "
                f"avec un profil de risque « {mandate['risk_profile']} »."
            ),
            (
                f"Depuis le début de l'année, la performance s'établit à {_pct(mandate['ytd_pct'])}."
            ),
            (
                f"L'allocation est {'conforme' if not breaches else 'à rééquilibrer'} : "
                f"{len(breaches)} classe(s) hors bande. Le mandat est en gestion depuis le "
                f"{mandate['inception_date'] or '—'} et les frais de gestion s'élèvent à "
                f"{mandate['management_fee_pct']:.2f} % par an."
            ),
        ]

    findings = []
    for row in breaches:
        findings.append(
            {
                "severity": "danger" if row["status"] == "Hors limite" else "warning",
                "label": f"{row['asset_class']} hors bande",
                "detail": (
                    f"Position {row['actual_pct']:.1f} % pour une cible de {row['target_pct']:.1f} % "
                    f"(bande {row['min_pct']:.1f}–{row['max_pct']:.1f} %)."
                ),
            }
        )
    if client.get("kyc_status") and client["kyc_status"] != "Validé":
        findings.append(
            {
                "severity": "warning",
                "label": "Revue KYC à compléter",
                "detail": f"Statut KYC : {client['kyc_status']}.",
            }
        )
    if mandate["status"] != "Actif":
        findings.append(
            {
                "severity": "info",
                "label": f"Cycle de vie : {mandate['status']}",
                "detail": f"Dernière revue le {mandate['last_review'] or '—'}.",
            }
        )

    kpis = [
        {"label": "Encours", "value": _eur(mandate["aum"]), "tone": "neutral"},
        {"label": "Perf. YTD", "value": _pct(mandate["ytd_pct"]), "tone": "pos" if mandate["ytd_pct"] >= 0 else "neg"},
        {"label": "Drawdown max", "value": f"{mandate['max_drawdown_pct']:.2f} %", "tone": "neg" if mandate["max_drawdown_pct"] < -5 else "neutral"},
        {"label": "Frais de gestion", "value": f"{mandate['management_fee_pct']:.2f} %", "tone": "neutral"},
    ]

    return {
        "meta": {
            "title": kind["label"],
            "subtitle": f"{mandate['mandate_name']} · {mandate['client_name']}",
            "report_type": report_type,
            "period": period,
            "as_of": as_of,
            "generated_at": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "client_id": mandate["client_id"],
            "mandate_id": mandate_id,
        },
        "client": {
            "client_name": client.get("client_name", mandate["client_name"]),
            "segment": client.get("segment", mandate["segment"]),
            "fund_manager": mandate.get("fund_manager", client.get("fund_manager", "")),
            "risk_profile": mandate.get("risk_profile", ""),
            "objectives": mandate.get("objectives", ""),
        },
        "mandate": mandate,
        "kpis": kpis,
        "narrative": paragraphs,
        "allocation": allocation["rows"],
        "actions": allocation["actions"],
        "holdings": allocation["holdings"],
        "performance": performance,
        "findings": findings,
        "footer": (
            "Document généré par SmartWealth à des fins de démonstration. Les performances passées "
            "ne préjugent pas des performances futures. Ce document ne constitue pas un conseil "
            "en investissement personnalisé."
        ),
    }


def build_workbook(report: dict[str, Any]) -> bytes:
    mandate = report["mandate"]
    client = report["client"]
    workbook = Workbook()

    thin = Side(style="thin", color="D9E2EC")
    border = Border(bottom=thin)

    def header(ws, title: str, columns: list[str]) -> None:
        ws.append([title])
        ws["A1"].font = Font(bold=True, size=14, color=NAVY)
        ws.append([])
        ws.append(columns)
        for cell in ws[3]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor=NAVY)
            cell.alignment = Alignment(horizontal="center")
        ws.freeze_panes = "A4"

    def widths(ws, values: list[int]) -> None:
        for index, width in enumerate(values, start=1):
            ws.column_dimensions[get_column_letter(index)].width = width

    summary = workbook.active
    summary.title = "Synthèse"
    summary.append(["SmartWealth — " + report["meta"]["title"]])
    summary["A1"].font = Font(bold=True, size=16, color=NAVY)
    summary.append([report["meta"]["subtitle"]])
    summary.append([f"Période : {report['meta']['period']} · Généré le {report['meta']['generated_at']}"])
    summary.append([])
    summary.append(["Client", client["client_name"]])
    summary.append(["Segment", client["segment"]])
    summary.append(["Fund manager", client["fund_manager"]])
    summary.append(["Profil de risque", mandate["risk_profile"]])
    summary.append(["Objectif", mandate["objectives"]])
    summary.append(["Mandat", mandate["mandate_name"]])
    summary.append(["Type de mandat", mandate["mandate_type"]])
    summary.append(["Stratégie", mandate["strategy"]])
    summary.append(["Portefeuille modèle", f"{mandate['model_name']} ({mandate['model_id']})"])
    summary.append(["Mise en gestion", mandate["inception_date"] or "—"])
    summary.append(["Statut", mandate["status"]])
    summary.append(["Conformité allocation", mandate["compliance"]])
    summary.append([])
    summary.append(["Indicateur", "Valeur"])
    for cell in summary[summary.max_row]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=TEAL)
    for item in report["kpis"]:
        summary.append([item["label"], item["value"]])
    summary.append([])
    summary.append(["Synthèse"])
    summary.cell(row=summary.max_row, column=1).font = Font(bold=True, size=12, color=NAVY)
    for paragraph in report["narrative"]:
        summary.append([paragraph])
        summary.cell(row=summary.max_row, column=1).alignment = Alignment(wrap_text=True, vertical="top")
        summary.merge_cells(
            start_row=summary.max_row, start_column=1, end_row=summary.max_row, end_column=3
        )
    widths(summary, [28, 40, 40])

    allocation = workbook.create_sheet("Allocation")
    header(
        allocation,
        "Allocation cible / réelle",
        ["Classe d'actifs", "Cible %", "Réel %", "Écart pts", "Min %", "Max %", "Valeur €", "Statut"],
    )
    for row in report["allocation"]:
        allocation.append(
            [
                row["asset_class"],
                row["target_pct"],
                row["actual_pct"],
                row["drift_pct"],
                row["min_pct"],
                row["max_pct"],
                row["market_value"],
                row["status"],
            ]
        )
    for row in allocation.iter_rows(min_row=4):
        row[1].number_format = '0.00" %"'
        row[2].number_format = '0.00" %"'
        row[3].number_format = '+0.00" pts";-0.00" pts"'
        row[4].number_format = '0.00" %"'
        row[5].number_format = '0.00" %"'
        row[6].number_format = '#,##0 "€"'
        for cell in row:
            cell.border = border
    widths(allocation, [22, 12, 12, 14, 10, 10, 16, 14])

    positions = workbook.create_sheet("Positions")
    header(
        positions,
        "Positions détenues",
        ["Instrument", "ISIN", "Classe", "Secteur", "Pays", "Valeur €", "Poids %", "P&L latent €"],
    )
    for row in report["holdings"]:
        positions.append(
            [
                row["instrument"],
                row["isin"],
                row["asset_class"],
                row["sector"],
                row["country"],
                row["market_value"],
                row["weight"],
                row["pnl_unrealised"],
            ]
        )
    for row in positions.iter_rows(min_row=4):
        row[5].number_format = '#,##0 "€"'
        row[6].number_format = '0.00" %"'
        row[7].number_format = '#,##0 "€"'
        for cell in row:
            cell.border = border
    widths(positions, [30, 16, 14, 18, 14, 16, 10, 16])

    performance = workbook.create_sheet("Performance")
    header(performance, "Performance 12 mois", ["Mois", "Portefeuille %"])
    for row in report["performance"]:
        performance.append([row["label"], row["portfolio"]])
    for row in performance.iter_rows(min_row=4):
        row[1].number_format = '0.00" %"'
        for cell in row:
            cell.border = border
    widths(performance, [14, 18])

    sheet = workbook.create_sheet("Contrôles")
    header(sheet, "Points de contrôle", ["Niveau", "Contrôle", "Détail"])
    for finding in report["findings"] or [{"severity": "ok", "label": "Aucun écart", "detail": "Tous les contrôles sont conformes."}]:
        sheet.append([finding["severity"], finding["label"], finding["detail"]])
    widths(sheet, [12, 34, 80])

    buffer = io.BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()
