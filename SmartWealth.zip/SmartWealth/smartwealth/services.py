from __future__ import annotations

import math
from datetime import date, datetime
from pathlib import Path
from typing import Any

import pandas as pd

from .storage import Repository, clean, records

ALLOCATION_BANDS = {"Monétaire": 3, "Immobilier": 4, "Alternatif": 4, "Or": 3}

REPORT_TYPES = [
    {
        "id": "mandate_review",
        "label": "Revue de mandat",
        "description": "Synthèse complète : client, mandat, allocation, positions et performance.",
    },
    {
        "id": "performance_review",
        "label": "Revue de performance",
        "description": "Performance et drawdown sur douze mois.",
    },
    {
        "id": "allocation_review",
        "label": "Contrôle d'allocation",
        "description": "Écarts cible / réel, dépassements de bandes et propositions de rééquilibrage.",
    },
]

DATA_SOURCES = {
    "positions": {
        "label": "Positions",
        "file": "holdings.parquet",
        "dataset": "holdings",
        "description": "Portefeuilles titres par mandat : quantité, prix, valeur de marché et P&L.",
        "required": [
            "mandate_id", "instrument", "isin", "asset_class", "sector", "country",
            "currency", "quantity", "price", "market_value", "weight", "cost_basis",
            "pnl_unrealised", "status",
        ],
    },
    "movements": {
        "label": "Mouvements",
        "file": "transactions.parquet",
        "dataset": "transactions",
        "description": "Opérations et flux par mandat : achats, ventes, frais et statut d'exécution.",
        "required": ["mandate_id", "client_id", "date", "type", "instrument", "amount", "status"],
    },
    "mandates": {
        "label": "Mandats",
        "file": "mandates.parquet",
        "dataset": "mandates",
        "description": "Caractéristiques des mandats : identifiant, portefeuille modèle, fund manager, devise, mise en gestion, performance YTD, profil et objectif.",
        "required": [
            "mandate_id", "model_id", "fund_manager", "base_ccy", "inception_date",
            "perf_ytd", "risk_profile", "objectives",
        ],
        "fields": [
            "mandate_id", "model_id", "fund_manager", "base_ccy", "inception_date",
            "perf_ytd", "risk_profile", "objectives",
        ],
    },
    "models": {
        "label": "Portefeuilles modèles",
        "file": "portfolio_models.parquet",
        "dataset": "portfolio_models",
        "description": "Inventaire des portefeuilles modèles : instruments, classes d'actifs et poids cibles.",
        "required": [
            "model_id", "model_name", "strategy", "risk_profile", "objectives",
            "asset_class", "instrument", "isin", "weight",
        ],
        "fields": [
            "model_id", "model_name", "strategy", "risk_profile", "objectives",
            "asset_class", "instrument", "isin", "weight",
        ],
    },
}

ACCENT = {
    "Conforme": "ok",
    "Alerte": "warn",
    "Hors limite": "err",
    "Non conforme": "err",
}


def _f(value: Any, digits: int = 2) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    if math.isnan(number) or math.isinf(number):
        return 0.0
    return round(number, digits)


def _pct(value: float) -> str:
    return f"{value:+.2f} %".replace(".", ",")


def _eur(value: float) -> str:
    return f"{value:,.0f} €".replace(",", " ")


def _date(value: Any) -> date | None:
    if value is None or value == "" or (isinstance(value, float) and math.isnan(value)):
        return None
    try:
        return pd.Timestamp(value).date()
    except (TypeError, ValueError):
        return None


def drift_status(drift: float, band: float) -> str:
    if abs(drift) <= band + 1e-6:
        return "Conforme"
    if abs(drift) <= 2 * band + 1e-6:
        return "Alerte"
    return "Hors limite"


class WealthService:
    def __init__(self, repository: Repository) -> None:
        self.repository = repository

    # -- data access -------------------------------------------------------
    @property
    def clients_frame(self) -> pd.DataFrame:
        return self.repository.load("clients")

    @property
    def mandates_frame(self) -> pd.DataFrame:
        return self.repository.load("mandates")

    @property
    def portfolio_models_frame(self) -> pd.DataFrame:
        return self.repository.load("portfolio_models")

    @property
    def holdings_frame(self) -> pd.DataFrame:
        return self.repository.load("holdings")

    @property
    def allocations_frame(self) -> pd.DataFrame:
        return self.repository.load("allocations")

    @property
    def performance_frame(self) -> pd.DataFrame:
        frame = self.repository.load("performance")
        frame["date"] = pd.to_datetime(frame["date"])
        return frame

    @property
    def transactions_frame(self) -> pd.DataFrame:
        return self.repository.load("transactions")

    @property
    def as_of(self) -> date:
        return self.performance_frame["date"].max().date()

    # -- computations ------------------------------------------------------
    def _stats(self, mandate_id: str) -> dict[str, Any]:
        perf = self.performance_frame
        perf = perf[perf["mandate_id"] == mandate_id].sort_values("date")
        if perf.empty:
            return {
                "ytd_pct": 0.0,
                "one_year_pct": 0.0,
                "max_drawdown_pct": 0.0,
                "best_month_pct": 0.0,
                "worst_month_pct": 0.0,
                "as_of": self.as_of.isoformat(),
            }

        year = perf["date"].max().year
        ytd = perf[perf["date"].dt.year == year]
        last12 = perf.tail(12)
        cumulative = 1 + perf["portfolio_cum"] / 100
        drawdown = (cumulative / cumulative.cummax() - 1) * 100

        return {
            "ytd_pct": _f(((1 + ytd["monthly_return"] / 100).prod() - 1) * 100),
            "one_year_pct": _f(((1 + last12["monthly_return"] / 100).prod() - 1) * 100),
            "max_drawdown_pct": _f(drawdown.min()),
            "best_month_pct": _f(last12["monthly_return"].max()),
            "worst_month_pct": _f(last12["monthly_return"].min()),
            "as_of": perf["date"].max().date().isoformat(),
        }

    def _allocation_rows(
        self, mandate_id: str, aum: float, model_id: str = ""
    ) -> list[dict[str, Any]]:
        targets = self.allocations_frame
        targets = targets[targets["mandate_id"] == mandate_id]
        holdings = self.holdings_frame
        holdings = holdings[holdings["mandate_id"] == mandate_id]
        actual = holdings.groupby("asset_class")["market_value"].sum().to_dict()
        target_map = {
            row["asset_class"]: row for row in records(targets)
        }
        model = self.portfolio_models_frame
        model = model[model["model_id"] == model_id] if model_id else model.iloc[0:0]
        model_weights = model.groupby("asset_class")["weight"].sum().to_dict()

        asset_classes = list(
            dict.fromkeys(
                list(target_map.keys()) + list(actual.keys()) + list(model_weights.keys())
            )
        )
        rows: list[dict[str, Any]] = []
        for asset_class in asset_classes:
            target = target_map.get(asset_class)
            target_pct = _f(target["target_pct"]) if target else 0.0
            model_pct = _f(model_weights.get(asset_class, 0.0))
            band = _f(target.get("band")) if target else 5.0
            band = ALLOCATION_BANDS.get(asset_class, band or 5.0)
            value = round(float(actual.get(asset_class, 0.0)), 2)
            actual_pct = _f(value / aum * 100) if aum else 0.0
            drift = _f(actual_pct - target_pct)
            min_pct = _f(target["min_pct"]) if target else max(0.0, target_pct - band)
            max_pct = _f(target["max_pct"]) if target else min(100.0, target_pct + band)
            rows.append(
                {
                    "asset_class": asset_class,
                    "target_pct": target_pct,
                    "model_pct": model_pct,
                    "actual_pct": actual_pct,
                    "min_pct": min_pct,
                    "max_pct": max_pct,
                    "band_pct": band,
                    "drift_pct": drift,
                    "model_drift_pct": _f(actual_pct - model_pct),
                    "market_value": value,
                    "status": drift_status(drift, band),
                }
            )
        rows.sort(key=lambda row: (-row["target_pct"], -row["actual_pct"]))
        return rows

    def _allocation_actions(
        self, rows: list[dict[str, Any]], aum: float
    ) -> list[dict[str, Any]]:
        actions = []
        for row in rows:
            drift = row["drift_pct"]
            if abs(drift) < 2:
                continue
            amount = round(abs(drift) / 100 * aum, 2)
            actions.append(
                {
                    "asset_class": row["asset_class"],
                    "action": "Acheter" if drift < 0 else "Vendre",
                    "amount": amount,
                    "drift_pct": drift,
                    "status": row["status"],
                }
            )
        actions.sort(key=lambda action: -abs(action["drift_pct"]))
        return actions[:6]

    def _compliance(self, rows: list[dict[str, Any]]) -> str:
        statuses = {row["status"] for row in rows}
        if "Hors limite" in statuses:
            return "Non conforme"
        if "Alerte" in statuses:
            return "Alerte"
        return "Conforme"

    def mandate_summary(self, row: dict[str, Any]) -> dict[str, Any]:
        mandate_id = row["mandate_id"]
        aum = _f(row["aum"])
        allocation = self._allocation_rows(mandate_id, aum, row.get("model_id", ""))
        stats = self._stats(mandate_id)
        holdings = self.holdings_frame
        holdings = holdings[holdings["mandate_id"] == mandate_id]
        worst = max(allocation, key=lambda item: abs(item["drift_pct"]), default=None)

        return {
            "mandate_id": mandate_id,
            "mandate_code": row.get("mandate_code", ""),
            "client_id": row["client_id"],
            "client_name": row.get("client_name", ""),
            "segment": row.get("segment", ""),
            "fund_manager": row.get("fund_manager", ""),
            "mandate_name": row["mandate_name"],
            "mandate_type": row["mandate_type"],
            "strategy": row["strategy"],
            "model_id": row.get("model_id", ""),
            "model_name": row.get("model_name", ""),
            "aum": aum,
            "base_ccy": row.get("base_ccy", "EUR"),
            "risk_profile": row.get("risk_profile", ""),
            "objectives": row.get("objectives", ""),
            "management_fee_pct": _f(row.get("management_fee_pct")),
            "inception_date": clean(row.get("inception_date")),
            "last_review": clean(row.get("last_review")),
            "status": row.get("status", "Actif"),
            "ytd_pct": stats["ytd_pct"],
            "one_year_pct": stats["one_year_pct"],
            "max_drawdown_pct": stats["max_drawdown_pct"],
            "best_month_pct": stats["best_month_pct"],
            "worst_month_pct": stats["worst_month_pct"],
            "compliance": self._compliance(allocation),
            "max_drift_pct": worst["drift_pct"] if worst else 0.0,
            "drift_asset_class": worst["asset_class"] if worst else "",
            "holdings_count": int(len(holdings)),
            "allocation": allocation,
            "as_of": stats["as_of"],
        }

    def _summary_for(self, mandate_id: str) -> dict[str, Any]:
        frame = self.mandates_frame
        frame = frame[frame["mandate_id"] == mandate_id]
        if frame.empty:
            raise KeyError(mandate_id)
        frame = frame.merge(
            self.portfolio_models_frame.drop_duplicates("model_id")[["model_id", "model_name"]],
            on="model_id",
            how="left",
        )
        row = records(frame)[0]
        client = self.clients_frame
        client = client[client["client_id"] == row["client_id"]]
        if not client.empty:
            client_row = records(client)[0]
            row["client_name"] = client_row["client_name"]
            row["segment"] = client_row["segment"]
        return self.mandate_summary(row)

    # -- public read models ------------------------------------------------
    def mandates(
        self,
        query: str = "",
        client_id: str = "",
        status: str = "",
        strategy: str = "",
    ) -> list[dict[str, Any]]:
        frame = self.mandates_frame.merge(
            self.portfolio_models_frame.drop_duplicates("model_id")[["model_id", "model_name"]],
            on="model_id",
            how="left",
        ).merge(
            self.clients_frame[
                ["client_id", "client_name", "segment", "kyc_status"]
            ],
            on="client_id",
            how="left",
        )
        if client_id:
            frame = frame[frame["client_id"] == client_id]
        if status:
            frame = frame[frame["status"] == status]
        if strategy:
            frame = frame[frame["strategy"] == strategy]
        if query:
            needle = query.strip().lower()
            mask = (
                frame["mandate_name"].str.lower().str.contains(needle, regex=False)
                | frame["client_name"].str.lower().str.contains(needle, regex=False)
                | frame["mandate_id"].str.lower().str.contains(needle, regex=False)
                | frame["mandate_code"].str.lower().str.contains(needle, regex=False)
            )
            frame = frame[mask]
        summaries = [self.mandate_summary(row) for row in records(frame)]
        summaries.sort(key=lambda item: (-item["aum"], item["mandate_name"]))
        return summaries

    def portfolio_models(self) -> list[dict[str, Any]]:
        frame = self.portfolio_models_frame
        summaries = self.mandates()
        by_model: dict[str, list[dict[str, Any]]] = {}
        for summary in summaries:
            by_model.setdefault(summary["model_id"], []).append(summary)

        models = []
        for model_id, group in frame.groupby("model_id", sort=False):
            head = group.iloc[0]
            linked = sorted(by_model.get(model_id, []), key=lambda item: -item["aum"])
            allocation = (
                group.groupby("asset_class", as_index=False)["weight"]
                .sum()
                .rename(columns={"weight": "target_pct"})
                .sort_values("target_pct", ascending=False)
            )
            holdings = group[
                ["instrument", "isin", "asset_class", "sector", "country", "currency", "weight"]
            ].sort_values("weight", ascending=False)
            models.append(
                {
                    "model_id": model_id,
                    "model_name": head["model_name"],
                    "strategy": head["strategy"],
                    "risk_profile": head["risk_profile"],
                    "objectives": head["objectives"],
                    "allocation": records(allocation),
                    "holdings": records(holdings),
                    "holdings_count": int(len(holdings)),
                    "mandate_count": len(linked),
                    "aum": _f(sum(item["aum"] for item in linked)),
                    "mandates": [
                        {
                            "mandate_id": item["mandate_id"],
                            "mandate_code": item["mandate_code"],
                            "mandate_name": item["mandate_name"],
                            "client_name": item["client_name"],
                            "aum": item["aum"],
                        }
                        for item in linked
                    ],
                }
            )
        return models

    def clients(self) -> list[dict[str, Any]]:
        clients = records(self.clients_frame)
        summaries = self.mandates()
        by_client: dict[str, list[dict[str, Any]]] = {}
        for summary in summaries:
            by_client.setdefault(summary["client_id"], []).append(summary)

        result = []
        for client in clients:
            mandates = by_client.get(client["client_id"], [])
            aum = sum(item["aum"] for item in mandates)
            weighted = sum(item["ytd_pct"] * item["aum"] for item in mandates)
            result.append(
                {
                    **client,
                    "mandates": mandates,
                    "mandate_count": len(mandates),
                    "aum": _f(aum),
                    "ytd_pct": _f(weighted / aum) if aum else 0.0,
                    "alerts": sum(1 for item in mandates if item["compliance"] != "Conforme"),
                }
            )
        result.sort(key=lambda item: -item["aum"])
        return result

    def client(self, client_id: str) -> dict[str, Any] | None:
        for client in self.clients():
            if client["client_id"] == client_id:
                return client
        return None

    def mandate(self, mandate_id: str) -> dict[str, Any]:
        return self._summary_for(mandate_id)

    def allocation(self, mandate_id: str) -> dict[str, Any]:
        mandate = self._summary_for(mandate_id)
        rows = mandate["allocation"]
        actions = self._allocation_actions(rows, mandate["aum"])
        holdings = self.holdings_frame
        holdings = holdings[holdings["mandate_id"] == mandate_id].sort_values(
            "market_value", ascending=False
        )
        return {
            "mandate": mandate,
            "rows": rows,
            "actions": actions,
            "holdings": records(holdings),
            "totals": {
                "aum": mandate["aum"],
                "target_total": _f(sum(row["target_pct"] for row in rows)),
                "actual_total": _f(sum(row["actual_pct"] for row in rows)),
                "breaches": sum(1 for row in rows if row["status"] != "Conforme"),
                "max_drift_pct": mandate["max_drift_pct"],
            },
        }

    def performance_series(self, mandate_id: str, months: int = 12) -> list[dict[str, Any]]:
        perf = self.performance_frame
        perf = perf[perf["mandate_id"] == mandate_id].sort_values("date")
        if perf.empty:
            return []
        window = perf.tail(months).reset_index(drop=True)
        base_port = float(perf.iloc[-len(window) - 1]["portfolio_cum"]) if len(perf) > len(window) else 0.0
        result = []
        for _, row in window.iterrows():
            result.append(
                {
                    "month": row["date"].strftime("%Y-%m"),
                    "label": row["period_label"],
                    "portfolio": _f(((1 + row["portfolio_cum"] / 100) / (1 + base_port / 100) - 1) * 100),
                }
            )
        return result

    def dashboard(self) -> dict[str, Any]:
        summaries = self.mandates()
        clients = self.clients()
        total_aum = sum(item["aum"] for item in summaries)
        weighted_ytd = sum(item["ytd_pct"] * item["aum"] for item in summaries)

        holdings = self.holdings_frame
        allocation = holdings.groupby("asset_class")["market_value"].sum().sort_values(ascending=False)
        allocation_total = float(allocation.sum()) or 1.0
        allocation_rows = [
            {
                "asset_class": asset_class,
                "market_value": _f(value),
                "weight": _f(value / allocation_total * 100),
            }
            for asset_class, value in allocation.items()
        ]

        by_strategy = (
            self.mandates_frame.groupby("strategy")["aum"].sum().sort_values(ascending=False)
        )
        strategy_rows = [
            {"strategy": strategy, "aum": _f(value)} for strategy, value in by_strategy.items()
        ]

        perf = self.performance_frame.copy()
        perf["weighted_return"] = perf["monthly_return"] * perf["aum"]
        grouped = perf.groupby("date").agg(
            weighted_return=("weighted_return", "sum"),
            aum=("aum", "sum"),
        )
        grouped["portfolio"] = (
            (1 + grouped["weighted_return"] / grouped["aum"] / 100).cumprod() - 1
        ) * 100
        perf_series = [
            {
                "month": index.strftime("%Y-%m"),
                "label": index.strftime("%b %y"),
                "portfolio": _f(row["portfolio"]),
            }
            for index, row in grouped.iterrows()
        ]

        today = self.as_of
        alerts: list[dict[str, Any]] = []
        for mandate in summaries:
            if mandate["compliance"] == "Conforme":
                continue
            severity = "danger" if mandate["compliance"] == "Non conforme" else "warning"
            worst = max(mandate["allocation"], key=lambda row: abs(row["drift_pct"]))
            alerts.append(
                {
                    "severity": severity,
                    "title": f"{mandate['mandate_name']} — écart d'allocation",
                    "detail": (
                        f"{worst['asset_class']} : cible {worst['target_pct']:.1f} %, "
                        f"réel {worst['actual_pct']:.1f} % ({worst['drift_pct']:+.1f} pts)."
                    ),
                    "mandate_id": mandate["mandate_id"],
                }
            )
        for client in clients:
            if client["kyc_status"] != "Validé":
                alerts.append(
                    {
                        "severity": "warning",
                        "title": f"{client['client_name']} — conformité KYC",
                        "detail": f"Statut KYC : {client['kyc_status']}.",
                        "client_id": client["client_id"],
                    }
                )
        alerts.sort(key=lambda item: 0 if item["severity"] == "danger" else 1)

        transactions = self.transactions_frame.merge(
            self.mandates_frame[["mandate_id", "mandate_name"]], on="mandate_id", how="left"
        ).merge(
            self.clients_frame[["client_id", "client_name"]], on="client_id", how="left"
        )
        transactions = transactions.sort_values("date", ascending=False).head(10)

        return {
            "as_of": today.isoformat(),
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "kpis": {
                "total_aum": _f(total_aum),
                "client_count": len(clients),
                "mandate_count": len(summaries),
                "weighted_ytd_pct": _f(weighted_ytd / total_aum) if total_aum else 0.0,
                "alerts": len(alerts),
                "breaches": sum(1 for item in summaries if item["compliance"] != "Conforme"),
                "avg_fee_pct": _f(
                    sum(item["management_fee_pct"] * item["aum"] for item in summaries) / total_aum
                )
                if total_aum
                else 0.0,
            },
            "allocation": allocation_rows,
            "strategies": strategy_rows,
            "performance": perf_series,
            "top_mandates": summaries[:6],
            "alerts": alerts[:8],
            "recent_transactions": records(transactions),
        }

    def report_catalog(self) -> dict[str, Any]:
        mandates = self.mandates_frame.merge(
            self.clients_frame[["client_id", "client_name"]], on="client_id", how="left"
        )
        return {
            "report_types": REPORT_TYPES,
            "mandates": [
                {
                    "mandate_id": row["mandate_id"],
                    "mandate_name": row["mandate_name"],
                    "client_id": row["client_id"],
                    "client_name": row.get("client_name", ""),
                    "strategy": row["strategy"],
                    "aum": _f(row["aum"]),
                }
                for row in records(mandates.sort_values(["client_name", "mandate_name"]))
            ],
            "as_of": self.as_of.isoformat(),
        }

    # -- data sources ------------------------------------------------------
    def data_sources(self) -> dict[str, Any]:
        return {
            "data_dir": str(self.repository.data_dir),
            "sources": [self._source_payload(key) for key in DATA_SOURCES],
        }

    def set_data_source(self, key: str, path: str) -> dict[str, Any]:
        spec = self._source_spec(key)
        resolved = Path(path).expanduser()
        if not resolved.is_absolute():
            resolved = self.repository.data_dir / resolved
        resolved = resolved.resolve()
        if not resolved.is_file():
            raise ValueError(f"Fichier introuvable : {resolved}")
        try:
            frame = pd.read_parquet(resolved)
        except Exception as exc:
            raise ValueError("Fichier Parquet illisible.") from exc
        missing = [column for column in spec["required"] if column not in frame.columns]
        if missing:
            raise ValueError("Colonnes manquantes : " + ", ".join(missing))
        self.repository.set_source(spec["dataset"], str(resolved))
        return self._source_payload(key)

    def reset_data_source(self, key: str) -> dict[str, Any]:
        spec = self._source_spec(key)
        self.repository.set_source(spec["dataset"], None)
        return self._source_payload(key)

    def data_source_path(self, key: str) -> Path | None:
        try:
            spec = self._source_spec(key)
        except KeyError:
            return None
        path = self.repository.source_path(spec["dataset"])
        return path if path.is_file() else None

    @staticmethod
    def _source_spec(key: str) -> dict[str, Any]:
        spec = DATA_SOURCES.get(key)
        if spec is None:
            raise KeyError(key)
        return spec

    def _source_payload(self, key: str) -> dict[str, Any]:
        spec = DATA_SOURCES[key]
        dataset = spec["dataset"]
        path = self.repository.source_path(dataset)
        source: dict[str, Any] = {
            "key": key,
            "label": spec["label"],
            "file": spec["file"],
            "description": spec["description"],
            "path": str(path),
            "default_path": str(self.repository.data_dir / spec["file"]),
            "custom": self.repository.source_override(dataset) is not None,
            "exists": path.is_file(),
        }
        if path.is_file():
            frame = self.repository.load(dataset)
            stat = path.stat()
            fields = spec.get("fields")
            view = frame[fields] if fields else frame
            source.update(
                rows=int(len(frame)),
                columns=[
                    {"name": name, "dtype": str(view[name].dtype)} for name in view.columns
                ],
                bytes=stat.st_size,
                modified_at=datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                preview=records(view.head(10)),
            )
        else:
            source.update(rows=0, columns=[], bytes=0, modified_at=None, preview=[])
        return source
