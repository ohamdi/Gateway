from __future__ import annotations

import json
import math
import threading
from pathlib import Path
from typing import Any

import pandas as pd


def clean(value: Any) -> Any:
    """Convert pandas/numpy scalars into JSON-safe Python values."""
    if value is None or value is pd.NaT:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    if isinstance(value, (pd.Timestamp,)):
        return value.strftime("%Y-%m-%d")
    if hasattr(value, "item"):
        value = value.item()
    if isinstance(value, float) and math.isnan(value):
        return None
    return value


def records(frame: pd.DataFrame) -> list[dict[str, Any]]:
    return [{key: clean(value) for key, value in row.items()} for row in frame.to_dict("records")]


class Repository:
    """Read the parquet files once and refresh them when their mtime changes.

    A source can be overridden by a custom path, persisted in the datasource config.
    """

    def __init__(self, data_dir: Path, config_path: Path | None = None) -> None:
        self.data_dir = data_dir
        self.config_path = config_path
        self._lock = threading.RLock()
        self._frames: dict[str, tuple[float, pd.DataFrame]] = {}
        self._users: list[dict[str, Any]] | None = None
        self._sources: dict[str, str] = self._read_sources()

    def source_path(self, name: str) -> Path:
        custom = self._sources.get(name)
        return Path(custom) if custom else self.data_dir / f"{name}.parquet"

    def source_override(self, name: str) -> str | None:
        return self._sources.get(name)

    def set_source(self, name: str, path: str | None) -> None:
        with self._lock:
            if path:
                self._sources[name] = path
            else:
                self._sources.pop(name, None)
            self._frames.pop(name, None)
            self._write_config()

    def load(self, name: str) -> pd.DataFrame:
        path = self.source_path(name)
        with self._lock:
            try:
                mtime = path.stat().st_mtime
            except FileNotFoundError as exc:
                raise FileNotFoundError(f"Jeu de données manquant : {path.name}") from exc
            cached = self._frames.get(name)
            if cached is None or cached[0] != mtime:
                cached = (mtime, pd.read_parquet(path))
                self._frames[name] = cached
            return cached[1].copy()

    def _read_config(self) -> dict[str, Any]:
        if self.config_path is None:
            return {}
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _read_sources(self) -> dict[str, str]:
        sources = self._read_config().get("sources")
        if not isinstance(sources, dict):
            return {}
        return {str(key): str(value) for key, value in sources.items()}

    def _write_config(self) -> None:
        if self.config_path is None:
            return
        payload = self._read_config()
        payload.setdefault("data_dir", str(self.data_dir))
        payload["sources"] = dict(self._sources)
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.config_path.with_suffix(self.config_path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.config_path)

    def users(self) -> list[dict[str, Any]]:
        with self._lock:
            if self._users is None:
                path = self.data_dir / "users.json"
                try:
                    self._users = json.loads(path.read_text(encoding="utf-8"))
                except (FileNotFoundError, json.JSONDecodeError):
                    self._users = []
            return list(self._users)
