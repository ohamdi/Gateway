"""SmartWealth — mandats, allocation et reporting."""
__version__ = "1.0.0"
