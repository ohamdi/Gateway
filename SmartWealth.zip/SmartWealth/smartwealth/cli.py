from __future__ import annotations

import os

import uvicorn


def main() -> None:
    uvicorn.run(
        "smartwealth.main:app",
        host=os.getenv("SMARTSWEALTH_HOST", "127.0.0.1"),
        port=int(os.getenv("SMARTSWEALTH_PORT", "5100")),
        reload=False,
    )


if __name__ == "__main__":
    main()
