from __future__ import annotations

import re
from typing import Annotated, Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, status
from fastapi.responses import FileResponse

from .auth import Principal, require_user
from .reporting import build_report, build_workbook
from .schemas import DataSourcePathRequest, LoginRequest, ReportRequest
from .services import WealthService

router = APIRouter(prefix="/api")
CurrentUser = Annotated[Principal, Depends(require_user)]


def get_service(request: Request) -> WealthService:
    return request.app.state.service


Service = Annotated[WealthService, Depends(get_service)]


def _not_found(message: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=message)


@router.post("/login")
def login(payload: LoginRequest, request: Request) -> dict[str, Any]:
    principal = request.app.state.authenticator.authenticate(payload.username, payload.password)
    if principal is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Identifiants invalides"
        )
    request.session.update(
        {
            "user": principal.username,
            "role": principal.role,
            "display_name": principal.display_name,
        }
    )
    return {
        "username": principal.username,
        "role": principal.role,
        "display_name": principal.display_name,
    }


@router.post("/logout")
def logout(request: Request) -> dict[str, bool]:
    request.session.clear()
    return {"ok": True}


@router.get("/me")
def me(user: CurrentUser) -> dict[str, Any]:
    return {
        "username": user.username,
        "role": user.role,
        "display_name": user.display_name,
    }


@router.get("/dashboard")
def dashboard(_user: CurrentUser, service: Service) -> dict[str, Any]:
    return service.dashboard()


@router.get("/clients")
def clients(_user: CurrentUser, service: Service) -> list[dict[str, Any]]:
    return service.clients()


@router.get("/clients/{client_id}")
def client(client_id: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    result = service.client(client_id)
    if result is None:
        raise _not_found("Client introuvable")
    return result


@router.get("/mandates")
def mandates(
    _user: CurrentUser,
    service: Service,
    q: str = "",
    client_id: str = "",
    status_filter: str = Query("", alias="status"),
    strategy: str = "",
) -> list[dict[str, Any]]:
    return service.mandates(q, client_id, status_filter, strategy)


@router.get("/mandates/{mandate_id}")
def mandate(mandate_id: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    try:
        return service.mandate(mandate_id)
    except KeyError as exc:
        raise _not_found("Mandat introuvable") from exc


@router.get("/mandates/{mandate_id}/allocation")
def allocation(mandate_id: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    try:
        return service.allocation(mandate_id)
    except KeyError as exc:
        raise _not_found("Mandat introuvable") from exc


@router.get("/portfolio-models")
def portfolio_models(_user: CurrentUser, service: Service) -> list[dict[str, Any]]:
    return service.portfolio_models()


@router.get("/datasources")
def datasources(_user: CurrentUser, service: Service) -> dict[str, Any]:
    return service.data_sources()


@router.put("/datasources/{key}")
def set_datasource(
    key: str, payload: DataSourcePathRequest, _user: CurrentUser, service: Service
) -> dict[str, Any]:
    try:
        return service.set_data_source(key, payload.path)
    except KeyError as exc:
        raise _not_found("Source de données introuvable") from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.delete("/datasources/{key}")
def reset_datasource(key: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    try:
        return service.reset_data_source(key)
    except KeyError as exc:
        raise _not_found("Source de données introuvable") from exc


@router.get("/datasources/{key}/download")
def datasource_download(key: str, _user: CurrentUser, service: Service) -> FileResponse:
    path = service.data_source_path(key)
    if path is None:
        raise _not_found("Source de données introuvable")
    return FileResponse(
        path, media_type="application/vnd.apache.parquet", filename=path.name
    )


@router.get("/reporting/catalog")
def report_catalog(_user: CurrentUser, service: Service) -> dict[str, Any]:
    return service.report_catalog()


@router.post("/reporting/generate")
def generate_report(
    payload: ReportRequest, _user: CurrentUser, service: Service
) -> dict[str, Any]:
    try:
        return build_report(service, payload.mandate_id, payload.report_type)
    except KeyError as exc:
        raise _not_found("Mandat introuvable") from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.get("/reporting/excel")
def report_excel(
    _user: CurrentUser,
    service: Service,
    mandate_id: str,
    report_type: str = "mandate_review",
) -> Response:
    try:
        report = build_report(service, mandate_id, report_type)
        content = build_workbook(report)
    except KeyError as exc:
        raise _not_found("Mandat introuvable") from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    filename = re.sub(
        r"[^A-Za-z0-9_-]+",
        "-",
        f"{report['client']['client_name']}-{report['mandate']['mandate_name']}-{report_type}",
    ).strip("-")
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}.xlsx"},
    )
