from __future__ import annotations

import os
import secrets
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    base_dir: Path
    data_dir: Path
    session_secret: str
    datasource_config: Path | None = None
    session_max_age: int = 8 * 60 * 60
    cookie_secure: bool = False

    @classmethod
    def from_env(cls) -> "Settings":
        base_dir = Path(
            os.getenv("SMARTSWEALTH_BASE_DIR", Path(__file__).resolve().parent.parent)
        ).resolve()
        data_dir = Path(os.getenv("SMARTSWEALTH_DATA_DIR", base_dir / "data")).resolve()
        return cls(
            base_dir=base_dir,
            data_dir=data_dir,
            session_secret=os.getenv("SMARTSWEALTH_SECRET_KEY") or secrets.token_hex(32),
            session_max_age=_int_env("SMARTSWEALTH_SESSION_MAX_AGE", 8 * 60 * 60),
            cookie_secure=_flag("SMARTSWEALTH_COOKIE_SECURE"),
        )

    @property
    def static_dir(self) -> Path:
        return self.base_dir / "static"

    @property
    def datasource_config_path(self) -> Path:
        return self.datasource_config or (self.base_dir / "datasource_config.json")


def _flag(name: str) -> bool:
    return os.getenv(name, "").strip().lower() in {"1", "true", "yes", "on"}


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default
