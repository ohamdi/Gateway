from __future__ import annotations

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class ReportRequest(BaseModel):
    mandate_id: str = Field(min_length=1, max_length=40)
    report_type: str = Field(default="mandate_review", max_length=40)


class DataSourcePathRequest(BaseModel):
    path: str = Field(min_length=1, max_length=4096)
