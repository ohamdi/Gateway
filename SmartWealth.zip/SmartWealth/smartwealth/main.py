from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from starlette.middleware.sessions import SessionMiddleware

from .auth import Authenticator
from .config import Settings
from .routes import router
from .services import WealthService
from .storage import Repository


def _cache_headers(path) -> dict[str, str]:
    if path.suffix.lower() in {".html", ".htm", ""}:
        return {"Cache-Control": "no-cache, no-store, must-revalidate"}
    return {"Cache-Control": "no-cache"}


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or Settings.from_env()
    repository = Repository(app_settings.data_dir, app_settings.datasource_config_path)
    service = WealthService(repository)

    application = FastAPI(
        title="SmartWealth API",
        version="1.0.0",
        description="Gestion de mandats, allocation et reporting pour le wealth management.",
    )
    application.state.settings = app_settings
    application.state.repository = repository
    application.state.service = service
    application.state.authenticator = Authenticator(repository)

    application.add_middleware(
        SessionMiddleware,
        secret_key=app_settings.session_secret,
        max_age=app_settings.session_max_age,
        same_site="lax",
        https_only=app_settings.cookie_secure,
    )

    @application.get("/health", tags=["system"])
    def health() -> dict[str, str]:
        return {"status": "ok"}

    application.include_router(router)

    @application.get("/{full_path:path}", include_in_schema=False)
    def frontend(full_path: str) -> FileResponse:
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="API route not found")
        static_dir = app_settings.static_dir.resolve()
        candidate = (static_dir / full_path).resolve()
        try:
            candidate.relative_to(static_dir)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail="Not found") from exc
        if candidate.is_file():
            return FileResponse(candidate, headers=_cache_headers(candidate))
        index = static_dir / "index.html"
        if not index.is_file():
            raise HTTPException(status_code=404, detail="Frontend not found")
        return FileResponse(index, headers=_cache_headers(index))

    return application


app = create_app()
