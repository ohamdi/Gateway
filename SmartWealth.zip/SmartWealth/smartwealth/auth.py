from __future__ import annotations

import hmac
from dataclasses import dataclass

from fastapi import HTTPException, Request, status

from .storage import Repository


@dataclass(frozen=True)
class Principal:
    username: str
    role: str
    display_name: str


class Authenticator:
    def __init__(self, repository: Repository) -> None:
        self.repository = repository

    def authenticate(self, username: str, password: str) -> Principal | None:
        for user in self.repository.users():
            if user.get("username") != username:
                continue
            if hmac.compare_digest(str(user.get("password", "")), password):
                return Principal(
                    username=username,
                    role=str(user.get("role", "user")),
                    display_name=str(user.get("display_name") or username),
                )
            return None
        return None


def principal_from_session(session: dict) -> Principal:
    username = session.get("user")
    if not username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentification requise"
        )
    return Principal(
        username=str(username),
        role=str(session.get("role", "user")),
        display_name=str(session.get("display_name") or username),
    )


def require_user(request: Request) -> Principal:
    return principal_from_session(request.session)
