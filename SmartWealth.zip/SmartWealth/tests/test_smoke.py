from __future__ import annotations

import io
import json

import pandas as pd
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from smartwealth.config import Settings
from smartwealth.main import create_app, app


def logged_in() -> TestClient:
    client = TestClient(app)
    response = client.post("/api/login", json={"username": "demo", "password": "demo"})
    assert response.status_code == 200
    return client


def test_requires_authentication() -> None:
    assert TestClient(app).get("/api/dashboard").status_code == 401


def test_dashboard_totals() -> None:
    payload = logged_in().get("/api/dashboard").json()
    assert payload["kpis"]["total_aum"] == 41_500_000
    assert payload["kpis"]["client_count"] == 10
    assert payload["kpis"]["mandate_count"] == 15
    assert len(payload["allocation"]) == 6


def test_allocation_flags_breach() -> None:
    payload = logged_in().get("/api/mandates/M007/allocation").json()
    assert payload["mandate"]["compliance"] == "Non conforme"
    assert payload["totals"]["breaches"] >= 1
    worst = max(payload["rows"], key=lambda row: abs(row["drift_pct"]))
    assert worst["asset_class"] == "Actions"
    assert payload["actions"][0]["action"] == "Vendre"
    assert all(
        {"model_pct", "model_drift_pct"} <= row.keys() for row in payload["rows"]
    )
    actions = next(row for row in payload["rows"] if row["asset_class"] == "Actions")
    assert actions["model_pct"] == 40
    assert abs(actions["model_drift_pct"] - (actions["actual_pct"] - 40)) < 0.02
    holding = payload["holdings"][0]
    assert {"instrument", "isin", "quantity", "price", "market_value", "weight", "pnl_unrealised", "status"} <= holding.keys()


def test_data_sources_expose_positions_and_movements() -> None:
    client = logged_in()
    payload = client.get("/api/datasources").json()
    sources = {source["key"]: source for source in payload["sources"]}
    assert sources["positions"]["file"] == "holdings.parquet"
    assert sources["positions"]["rows"] == 141
    assert len(sources["positions"]["preview"]) == 10
    assert sources["movements"]["file"] == "transactions.parquet"
    assert sources["movements"]["rows"] == 90
    assert sources["mandates"]["file"] == "mandates.parquet"
    assert sources["mandates"]["rows"] == 15
    assert [column["name"] for column in sources["mandates"]["columns"]] == [
        "mandate_id", "model_id", "fund_manager", "base_ccy", "inception_date",
        "perf_ytd", "risk_profile", "objectives",
    ]
    assert len(sources["mandates"]["preview"]) == 10
    assert sources["models"]["file"] == "portfolio_models.parquet"
    assert sources["models"]["rows"] == 43
    assert [column["name"] for column in sources["models"]["columns"]] == [
        "model_id", "model_name", "strategy", "risk_profile", "objectives",
        "asset_class", "instrument", "isin", "weight",
    ]

    download = client.get("/api/datasources/positions/download")
    assert download.status_code == 200
    assert download.content[:4] == b"PAR1"
    assert client.get("/api/datasources/unknown/download").status_code == 404


def test_data_source_path_override(tmp_path) -> None:
    defaults = app.state.settings
    custom = tmp_path / "positions.parquet"
    custom.write_bytes((defaults.data_dir / "holdings.parquet").read_bytes())
    config = tmp_path / "datasource_config.json"
    client = TestClient(
        create_app(
            Settings(
                base_dir=defaults.base_dir,
                data_dir=defaults.data_dir,
                session_secret="test",
                datasource_config=config,
            )
        )
    )
    client.post("/api/login", json={"username": "demo", "password": "demo"})

    saved = client.put("/api/datasources/positions", json={"path": str(custom)})
    assert saved.status_code == 200
    assert saved.json()["custom"] is True
    assert saved.json()["path"] == str(custom.resolve())
    assert saved.json()["rows"] == 141
    assert json.loads(config.read_text(encoding="utf-8"))["sources"]["holdings"] == str(
        custom.resolve()
    )

    missing = client.put("/api/datasources/positions", json={"path": str(tmp_path / "nope.parquet")})
    assert missing.status_code == 400

    wrong_schema = tmp_path / "wrong.parquet"
    pd.DataFrame({"a": [1]}).to_parquet(wrong_schema)
    assert client.put("/api/datasources/positions", json={"path": str(wrong_schema)}).status_code == 400

    reset = client.delete("/api/datasources/positions")
    assert reset.status_code == 200
    assert reset.json()["custom"] is False
    assert reset.json()["path"].endswith("holdings.parquet")


def test_clients_expose_fund_manager_and_mandate_code() -> None:
    client = logged_in()
    clients = client.get("/api/clients").json()
    assert all(item["fund_manager"] for item in clients)
    assert "relationship_manager" not in clients[0]

    codes = {mandate["mandate_code"] for item in clients for mandate in item["mandates"]}
    assert "SW-001" in codes
    assert len(codes) == 15

    mandate = client.get("/api/mandates/M001").json()
    assert mandate["mandate_code"] == "SW-001"
    assert mandate["fund_manager"]
    assert mandate["model_id"] == "PM-03" and mandate["model_name"] == "Modèle Équilibré"
    assert mandate["risk_profile"] and mandate["objectives"] and mandate["inception_date"]
    assert "risk_level" not in mandate
    assert "next_review" not in mandate
    assert "volatility_pct" not in mandate
    assert "sharpe" not in mandate
    assert "benchmark" not in mandate


def test_portfolio_models_link_mandates() -> None:
    payload = logged_in().get("/api/portfolio-models").json()
    assert len(payload) == 5
    models = {model["model_id"]: model for model in payload}
    expected = {"PM-01": "Trésorerie", "PM-02": "Défensif", "PM-03": "Équilibré",
                "PM-04": "Croissance", "PM-05": "Dynamique"}
    assert {key: model["strategy"] for key, model in models.items()} == expected
    assert sum(model["mandate_count"] for model in payload) == 15
    assert abs(sum(model["aum"] for model in payload) - 41_500_000) < 1
    assert all(len(model["allocation"]) >= 2 for model in payload)
    assert all(model["holdings"] and model["holdings_count"] == len(model["holdings"]) for model in payload)
    assert all(abs(sum(item["weight"] for item in model["holdings"]) - 100) < 0.05 for model in payload)
    assert models["PM-03"]["mandate_count"] >= 1
    assert all(
        item["mandate_id"].startswith("M") for model in payload for item in model["mandates"]
    )


def test_report_and_excel_export() -> None:
    client = logged_in()
    response = client.post(
        "/api/reporting/generate",
        json={"mandate_id": "M001", "report_type": "mandate_review"},
    )
    assert response.status_code == 200
    report = response.json()
    assert report["meta"]["mandate_id"] == "M001"
    assert len(report["allocation"]) == 6
    assert len(report["narrative"]) == 3

    excel = client.get(
        "/api/reporting/excel",
        params={"mandate_id": "M001", "report_type": "mandate_review"},
    )
    assert excel.status_code == 200
    workbook = load_workbook(io.BytesIO(excel.content))
    assert workbook.sheetnames == ["Synthèse", "Allocation", "Positions", "Performance", "Contrôles"]
    summary_values = [cell.value for row in workbook["Synthèse"].iter_rows() for cell in row]
    assert "Portefeuille modèle" in summary_values
    assert "Modèle Équilibré (PM-03)" in summary_values
