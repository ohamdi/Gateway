# SmartWealth

Application de gestion de mandats de wealth management, inspirée de la structure de
SmartPMS : backend FastAPI, frontend single-page (Bootstrap 5 + Chart.js) et données
locales Parquet.

## Onglets

| Onglet | Contenu |
|---|---|
| **Dashboard** | Encours consolidé, performance 24 mois, allocation, alertes de dérive, dernières opérations. |
| **ClientMandate** | Filtre client (segment, profil de risque du mandat, **FundManager**, **MandateCode**) et sélection du client dans une liste déroulante, fiche client (KYC), cartes des mandats (MandateCode, portefeuille modèle, fund manager, profil de risque, devise, mise en gestion, objectif) et **inventaire des positions du mandat sélectionné** : vue groupée = sous-totaux par classe + total général, vue dégroupée = toutes les positions avec statut, sous-totaux par classe + total général. |
| **PortfolioModel** | Sélection d'un portefeuille modèle : stratégie, profil de risque, objectif, encours rattaché, allocation cible par classe, inventaire des instruments et mandats liés. |
| **MandateAllocation** | Allocation cible / réelle par classe d'actifs, comparaison avec le portefeuille modèle rattaché, bandes de tolérance, statut de conformité, propositions de rééquilibrage et positions. |
| **Reporting** | Aperçu imprimable d'une revue de mandat, de performance ou de contrôle d'allocation, export Excel multi-feuilles. |
| **DataSource** | Sources Parquet de l'application : mandats (`mandates.parquet` : identifiant, portefeuille modèle, fund manager, devise, mise en gestion, perf YTD, profil, objectif), portefeuilles modèles (`portfolio_models.parquet` : modèle, inventaire des instruments et poids cibles), positions (`holdings.parquet` : statut par ligne) et mouvements (`transactions.parquet`). Permet de saisir un chemin personnalisé, validé puis chargé, avec schéma, aperçu et téléchargement. |

## Lancer l'application

```bash
cd /home/ohamdi/Bureau/Documents/SmartWealth
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python scripts/seed_data.py          # régénère les données de démonstration
python app.py                        # http://127.0.0.1:5100
```

Compte de démonstration : **demo / demo** (également `conseiller / conseiller123`).

Variables d'environnement utiles : `SMARTSWEALTH_HOST`, `SMARTSWEALTH_PORT`,
`SMARTSWEALTH_DATA_DIR`, `SMARTSWEALTH_SECRET_KEY`.

Depuis l'onglet **DataSource**, le chemin des fichiers mandats, positions et mouvements peut être
remplacé par n'importe quel Parquet local. Le chemin est mémorisé dans
`datasource_config.json` (clé `sources`) ; le fichier doit contenir les mêmes colonnes
que le fichier fourni, sinon il est refusé.

## Structure

```
app.py                  point d'entrée (python app.py)
datasource_config.json  chemins personnalisés des sources Parquet
smartwealth/
  main.py               application FastAPI + service des fichiers statiques
  routes.py             endpoints /api
  services.py           agrégats dashboard, clients, mandats, allocations
  reporting.py          construction des rapports et export Excel
  auth.py               session + authentification (démo)
  config.py             réglages
  storage.py            lecture Parquet avec cache
  schemas.py            modèles de requêtes
scripts/seed_data.py    génération déterministe du jeu de données
static/index.html       interface (6 onglets)
data/                   clients, mandats, portefeuilles modèles, positions, allocations, performance, transactions
tests/test_smoke.py     vérifications API / export
```

## API principale

- `POST /api/login`, `POST /api/logout`, `GET /api/me`
- `GET /api/dashboard`
- `GET /api/clients`, `GET /api/clients/{id}`
- `GET /api/mandates`, `GET /api/mandates/{id}`, `GET /api/mandates/{id}/allocation`
- `GET /api/portfolio-models`
- `GET /api/reporting/catalog`
- `POST /api/reporting/generate`
- `GET /api/reporting/excel?mandate_id=…&report_type=…`
- `GET /api/datasources`, `GET /api/datasources/{mandates|models|positions|movements}/download`
- `PUT /api/datasources/{mandates|models|positions|movements}` avec `{"path": "/chemin/fichier.parquet"}`
- `DELETE /api/datasources/{mandates|models|positions|movements}` (retour au fichier par défaut)

Les données sont synthétiques. Les mots de passe sont stockés en clair dans
`data/users.json` : configuration de démonstration uniquement, à remplacer avant
tout usage réel.
